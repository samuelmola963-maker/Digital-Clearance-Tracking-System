import React, { useState } from 'react';
import { useClearance } from '../context/ClearanceContext';
import { ClearanceHold, ClearanceType, DepartmentKey } from '../types/clearance';
import { DEPARTMENTS_METADATA } from '../data/mockData';
import { VacationGatePassModal } from './VacationGatePassModal';
import { ReplacementIdCardModal } from './ReplacementIdCardModal';
import {
  AlertCircle,
  Building2,
  Calendar,
  CheckCircle2,
  Clock,
  CreditCard,
  FileText,
  GraduationCap,
  IdCard,
  Info,
  Luggage,
  MapPin,
  PlusCircle,
  ShieldAlert,
  ShieldCheck,
  User,
  Users,
} from 'lucide-react';

interface Props {
  onOpenCertificate: () => void;
  onOpenAuthModal?: () => void;
}

export const StudentPortal: React.FC<Props> = ({ onOpenCertificate, onOpenAuthModal }) => {
  const {
    students,
    activeStudentId,
    setActiveStudentId,
    currentStudent,
    currentRequest,
    resolveHold,
    initiateClearance,
    payLostIdReplacementFee,
    logout,
  } = useClearance();

  // State for resolving a hold modal
  const [selectedHold, setSelectedHold] = useState<{
    hold: ClearanceHold;
    deptKey: DepartmentKey;
    deptName: string;
  } | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'Telebirr' | 'CBE Birr' | 'Physical Return'>('Telebirr');
  const [receiptCode, setReceiptCode] = useState('');
  const [isSubmittingHold, setIsSubmittingHold] = useState(false);

  // Modals for Vacation Pass & Replacement ID
  const [isVacationModalOpen, setIsVacationModalOpen] = useState(false);
  const [isReplacementIdModalOpen, setIsReplacementIdModalOpen] = useState(false);

  // State for new clearance application modal
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [newClearanceType, setNewClearanceType] = useState<ClearanceType>('VACATION_EXIT');
  const [newReason, setNewReason] = useState('Semester break vacation travel & luggage clearance (Boqonnaaf Gibiidhaa Ba\'uu)');
  const [newAcademicYear, setNewAcademicYear] = useState('2025/2026');
  const [newSemester, setNewSemester] = useState<'I' | 'II' | 'Summer'>('II');
  
  // Extra fields for Vacation & Lost ID
  const [destinationTown, setDestinationTown] = useState('Nekemte');
  const [departureDate, setDepartureDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [expectedReturnDate, setExpectedReturnDate] = useState(() => new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [policeReportNo, setPoliceReportNo] = useState(`DaDU-POL-2026-${Math.floor(1000 + Math.random() * 9000)}`);
  const [incidentLocation, setIncidentLocation] = useState('Main Campus Dining Plaza');

  // Compute stats
  const departmentsList = currentRequest
    ? (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).map((key) => ({
        key,
        meta: DEPARTMENTS_METADATA[key],
        approval: currentRequest.departments[key],
      }))
    : [];

  const clearedCount = departmentsList.filter((d) => d.approval?.status === 'CLEARED').length;
  const totalCount = departmentsList.length || 9;
  const progressPercent = totalCount > 0 ? Math.round((clearedCount / totalCount) * 100) : 0;

  // Collect all active unresolved holds across all departments
  const allActiveHolds: Array<{
    hold: ClearanceHold;
    deptKey: DepartmentKey;
    deptName: string;
  }> = [];

  if (currentRequest) {
    (Object.keys(currentRequest.departments) as DepartmentKey[]).forEach((deptKey) => {
      const dept = currentRequest.departments[deptKey];
      dept.holds
        .filter((h) => !h.resolved)
        .forEach((hold) => {
          allActiveHolds.push({
            hold,
            deptKey,
            deptName: dept.departmentName,
          });
        });
    });
  }

  const handleResolveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHold || !currentRequest) return;
    setIsSubmittingHold(true);

    setTimeout(() => {
      resolveHold(
        currentRequest.id,
        selectedHold.deptKey,
        selectedHold.hold.id,
        paymentMethod,
        receiptCode || `${paymentMethod.slice(0, 3).toUpperCase()}-${Math.floor(100000 + Math.random() * 900000)}`
      );
      setIsSubmittingHold(false);
      setSelectedHold(null);
      setReceiptCode('');
    }, 400);
  };

  const handleCreateClearance = (e: React.FormEvent) => {
    e.preventDefault();
    initiateClearance({
      studentId: currentStudent.id,
      clearanceType: newClearanceType,
      reason: newReason,
      academicYear: newAcademicYear,
      semester: newSemester,
      vacationExitPass:
        newClearanceType === 'VACATION_EXIT'
          ? {
              destinationTown: destinationTown || 'Nekemte',
              departureDate,
              expectedReturnDate,
              luggagePermitIssued: true,
              gateSecurityExitCleared: false,
            }
          : undefined,
      lostIdIncident:
        newClearanceType === 'LOST_ID_REPLACEMENT'
          ? {
              policeReportNo: policeReportNo || `DaDU-POL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
              incidentDate: new Date().toISOString().split('T')[0],
              incidentLocation: incidentLocation || 'Main Campus Dining Plaza',
              replacementFeeETB: 150,
              replacementFeePaid: false,
              replacementIdIssued: false,
            }
          : undefined,
    });
    setIsApplyModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Student Switcher & Profile Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="flex items-start gap-4">
            <img
              src={currentStudent.avatarUrl}
              alt={currentStudent.fullName}
              className="w-16 h-16 rounded-lg object-cover border border-slate-200 shadow-xs shrink-0"
              referrerPolicy="no-referrer"
            />
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-bold text-slate-900">{currentStudent.fullName}</h2>
                <span className="text-xs font-mono px-2 py-0.5 bg-slate-100 text-slate-700 rounded">
                  {currentStudent.studentId}
                </span>
                <span className="text-xs px-2 py-0.5 bg-blue-50 text-blue-800 rounded font-bold">
                  {currentStudent.yearOfStudy || 'Graduating Class'}
                </span>
                <span className="text-xs px-2 py-0.5 bg-amber-50 text-amber-800 rounded font-medium">
                  {currentStudent.program} Program
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600 mt-1 flex-wrap">
                <span className="font-semibold text-slate-900">{currentStudent.department}</span>
                <span aria-hidden="true">·</span>
                <span>{currentStudent.college}</span>
                <span aria-hidden="true">·</span>
                <span>CGPA: <strong className="font-mono text-slate-900">{currentStudent.cgpa}</strong></span>
              </div>
              <div className="flex items-center gap-3 text-xs text-slate-500 mt-2 font-mono">
                <span>Dorm: {currentStudent.dormBlock}, {currentStudent.dormRoom}</span>
                <span aria-hidden="true">·</span>
                <span>Cost Sharing: {currentStudent.costSharingAgreementNo}</span>
              </div>
            </div>
          </div>

          {/* Quick Demo Switcher & Account Creation Button */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
            {onOpenAuthModal && (
              <button
                type="button"
                onClick={onOpenAuthModal}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors cursor-pointer shadow-xs"
              >
                <span>+ Create Account</span>
              </button>
            )}

            <button
              type="button"
              onClick={logout}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
            >
              <span>Log Out</span>
            </button>

            <div className="flex items-center gap-1.5">
              <span className="text-xs text-slate-500 font-medium hidden md:inline">
                Record:
              </span>
              <select
                value={activeStudentId}
                onChange={(e) => setActiveStudentId(e.target.value)}
                className="px-3 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:outline-hidden cursor-pointer"
              >
                {students.map((std) => (
                  <option key={std.id} value={std.id}>
                    {std.fullName} ({std.studentId})
                  </option>
                ))}
              </select>
            </div>

            {!currentRequest ? (
              <button
                onClick={() => setIsApplyModalOpen(true)}
                className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                Apply for Clearance
              </button>
            ) : null}
          </div>
        </div>

        {/* Quick Demo Scenario Switcher Pills */}
        <div className="mt-4 pt-3 border-t border-slate-100 flex flex-wrap items-center gap-2 text-xs">
          <span className="font-semibold text-slate-500">Test Scenarios:</span>
          <button
            onClick={() => setActiveStudentId('std_01')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              activeStudentId === 'std_01'
                ? 'bg-slate-900 text-white font-bold'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            🎓 Tolosa Gemechu (Graduation Cleared)
          </button>
          <button
            onClick={() => setActiveStudentId('std_02')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              activeStudentId === 'std_02'
                ? 'bg-emerald-800 text-white font-bold'
                : 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100'
            }`}
          >
            🧳 Hawi Tadesse (Vacation & Luggage Exit Pass)
          </button>
          <button
            onClick={() => setActiveStudentId('std_03')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium transition-colors cursor-pointer ${
              activeStudentId === 'std_03'
                ? 'bg-amber-600 text-white font-bold'
                : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            💳 Bonsa Deriba (Lost Student ID Multi-Sector Clearance)
          </button>
        </div>
      </div>

      {/* SPECIAL PURPOSE BANNER: VACATION & CAMPUS EXIT (Boqonnaaf Gibiidhaa Ba'uu) */}
      {currentRequest?.clearanceType === 'VACATION_EXIT' && (
        <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white rounded-xl p-5 shadow-sm border border-emerald-700">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase bg-emerald-400 text-emerald-950 tracking-wider">
                <Luggage className="w-3.5 h-3.5" />
                Vacation & Campus Exit Clearance (Boqonnaaf Gibiidhaa Ba'uu)
              </div>
              <h3 className="text-lg font-bold">
                Semester Break Campus Exit & Luggage Authorization
              </h3>
              <p className="text-xs text-emerald-100 max-w-2xl leading-relaxed">
                Before leaving Danbi Dollo University campus for semester break, you must surrender your dormitory room key to your proctor, return all checked-out library books, and present your Luggage Permit at the Main Security Gate.
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-emerald-200">
                <div className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-300" />
                  <span>Destination: <strong className="text-white">{currentRequest.vacationExitPass?.destinationTown || 'Nekemte'}</strong></span>
                </div>
                <span>·</span>
                <div>
                  Exit Date: <strong className="text-white">{currentRequest.vacationExitPass?.departureDate || '2026-10-28'}</strong>
                </div>
                <span>·</span>
                <div>
                  Expected Return: <strong className="text-white">{currentRequest.vacationExitPass?.expectedReturnDate || '2026-11-20'}</strong>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
              <button
                onClick={() => setIsVacationModalOpen(true)}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs shadow-md transition-colors cursor-pointer"
              >
                <Luggage className="w-4 h-4" />
                View & Print Vacation Gate Pass
              </button>
            </div>
          </div>
        </div>
      )}

      {/* SPECIAL PURPOSE BANNER: LOST STUDENT ID REPLACEMENT (Clearance Yeroo ID Card Gatan) */}
      {currentRequest?.clearanceType === 'LOST_ID_REPLACEMENT' && (
        <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 text-white rounded-xl p-5 shadow-sm border border-amber-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase bg-amber-400 text-slate-950 tracking-wider">
                <IdCard className="w-3.5 h-3.5" />
                Lost Student ID Multi-Sector Clearance (Clearance Yeroo ID Card Gatan)
              </div>
              <h3 className="text-lg font-bold">
                Multi-Sector Investigation & Replacement ID Card Reissuance
              </h3>
              <p className="text-xs text-amber-100 max-w-2xl leading-relaxed">
                When a student loses their ID card, university regulations require multi-sector clearance: Campus Police incident filing, Library loan audit, Cafeteria barcode blockage (to prevent meal theft), Proctor physical verification, and Finance replacement fee settlement.
              </p>
              <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-amber-200">
                <div>
                  Police Report: <strong className="text-white">{currentRequest.lostIdIncident?.policeReportNo || 'DaDU-POL-2026-8812'}</strong>
                </div>
                <span>·</span>
                <div>
                  Dining Card Barcode: <strong className="text-emerald-400">Blocked & Protected</strong>
                </div>
                <span>·</span>
                <div>
                  Replacement Fee: <strong className="text-white">150 ETB ({currentRequest.lostIdIncident?.replacementFeePaid ? 'Paid' : 'Unpaid'})</strong>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 shrink-0">
              {!currentRequest.lostIdIncident?.replacementFeePaid && (
                <button
                  onClick={() => payLostIdReplacementFee(currentRequest.id, 'Telebirr')}
                  className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs shadow-md transition-colors cursor-pointer"
                >
                  <CreditCard className="w-4 h-4" />
                  Pay 150 ETB via Telebirr
                </button>
              )}
              <button
                onClick={() => setIsReplacementIdModalOpen(true)}
                className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg text-xs shadow-md transition-colors cursor-pointer"
              >
                <IdCard className="w-4 h-4" />
                View Replacement ID & Sector Slip
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Clearance Status Banner */}
      {currentRequest ? (
        <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Application #{currentRequest.id.slice(0, 12)}
                </span>
                <span className="text-xs text-slate-400">·</span>
                <span className="text-xs font-medium text-slate-600">
                  {currentRequest.academicYear} (Semester {currentRequest.semester})
                </span>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mt-0.5">
                {currentRequest.clearanceType === 'VACATION_EXIT'
                  ? 'Vacation & Luggage Exit Pass Clearance (Boqonnaaf Gibiidhaa Ba\'uu)'
                  : currentRequest.clearanceType === 'LOST_ID_REPLACEMENT'
                  ? 'Lost Student ID Card Multi-Sector Clearance'
                  : `${currentRequest.clearanceType} Clearance Tracking`}
              </h3>
              <p className="text-xs text-slate-500 mt-1">{currentRequest.reason}</p>
            </div>

            {/* Overall Status Badge */}
            <div className="flex items-center gap-3">
              {currentRequest.overallStatus === 'APPROVED' ? (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg text-xs font-semibold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Approved & Cleared</span>
                </div>
              ) : currentRequest.overallStatus === 'ACTION_REQUIRED' ? (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-lg text-xs font-semibold">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>{allActiveHolds.length} Holds Require Settlement</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg text-xs font-semibold">
                  <Clock className="w-4 h-4 text-amber-600" />
                  <span>In Progress ({clearedCount}/{totalCount} Cleared)</span>
                </div>
              )}

              {currentRequest.finalCertificateIssued && (
                <button
                  onClick={onOpenCertificate}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  View Official Slip
                </button>
              )}
            </div>
          </div>

          {/* Progress Bar */}
          <div className="pt-4">
            <div className="flex justify-between items-center text-xs mb-1.5">
              <span className="font-semibold text-slate-700">Clearance Pipeline Completion</span>
              <span className="font-mono font-bold text-slate-900">{progressPercent}% ({clearedCount} of {totalCount} Offices Cleared)</span>
            </div>
            <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-500 rounded-full ${
                  progressPercent === 100 ? 'bg-emerald-600' : 'bg-slate-900'
                }`}
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
          <GraduationCap className="w-12 h-12 text-slate-400 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-900">No Active Clearance Application</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
            This student record does not currently have an open clearance cycle. Click below to begin a graduation or end-of-year clearance request.
          </p>
          <button
            onClick={() => setIsApplyModalOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            Start University Clearance
          </button>
        </div>
      )}

      {/* Active Holds Banner (if any) */}
      {allActiveHolds.length > 0 && (
        <div className="bg-rose-50/50 border border-rose-200 rounded-xl p-5">
          <div className="flex items-start gap-3">
            <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-rose-950">
                  Active Department Liabilities & Holds ({allActiveHolds.length})
                </h4>
                <span className="text-xs font-mono font-semibold text-rose-800">
                  Total Outstanding: {allActiveHolds.reduce((acc, h) => acc + (h.hold.amountETB || 0), 0)} ETB
                </span>
              </div>
              <p className="text-xs text-rose-700 mt-0.5">
                University clearance cannot proceed to final registrar sign-off until the following items are settled or returned:
              </p>

              <div className="mt-3 space-y-2">
                {allActiveHolds.map(({ hold, deptKey, deptName }) => (
                  <div
                    key={hold.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-white border border-rose-200 rounded-lg"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{deptName}</span>
                        <span className="text-[10px] font-mono uppercase px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded">
                          {hold.category}
                        </span>
                      </div>
                      <div className="text-xs text-slate-800 font-medium mt-1">{hold.item}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{hold.instructions}</div>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                      {hold.amountETB ? (
                        <div className="text-right">
                          <span className="text-sm font-mono font-bold text-slate-950">
                            {hold.amountETB} ETB
                          </span>
                        </div>
                      ) : null}
                      <button
                        onClick={() =>
                          setSelectedHold({
                            hold,
                            deptKey,
                            deptName,
                          })
                        }
                        className="px-3 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-md transition-colors cursor-pointer"
                      >
                        Settle Hold
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 9 Department Clearance Grid */}
      {currentRequest && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Department Sign-off Directory</h3>
              <p className="text-xs text-slate-500">
                Official Danbi Dollo University administrative offices required for complete clearance.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-500">
              {clearedCount} / {totalCount} Cleared
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departmentsList.map(({ key, meta, approval }) => {
              const isCleared = approval?.status === 'CLEARED';
              const isHold = approval?.status === 'HOLD';
              const isPending = !isCleared && !isHold;

              return (
                <div
                  key={key}
                  className={`bg-white border rounded-xl p-4 transition-shadow hover:shadow-xs flex flex-col justify-between ${
                    isCleared
                      ? 'border-emerald-200'
                      : isHold
                      ? 'border-rose-300 ring-1 ring-rose-200'
                      : 'border-slate-200'
                  }`}
                >
                  <div>
                    {/* Header */}
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h4 className="text-sm font-bold text-slate-900 truncate">{meta.name}</h4>
                        <div className="text-[11px] text-slate-500 font-medium">{meta.subtitle}</div>
                      </div>
                      <div className="shrink-0">
                        {isCleared ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Cleared
                          </span>
                        ) : isHold ? (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                            <AlertCircle className="w-3 h-3 text-rose-600" />
                            Hold
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            <Clock className="w-3 h-3 text-amber-600" />
                            Pending
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Officer & Location Details */}
                    <div className="mt-3 pt-3 border-t border-slate-100 text-xs space-y-1">
                      <div className="flex items-center gap-1.5 text-slate-600">
                        <User className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{approval?.officerName || meta.leadOfficer}</span>
                      </div>
                      <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span className="truncate">{meta.building}</span>
                      </div>
                    </div>

                    {/* Remarks / Notes */}
                    <div className="mt-2.5 text-xs text-slate-600 bg-slate-50 p-2 rounded">
                      <span className="font-semibold text-slate-800">Officer Remarks: </span>
                      {approval?.notes || meta.description}
                    </div>
                  </div>

                  {/* Stamp & Verification Bottom Bar */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px]">
                    {isCleared ? (
                      <>
                        <span className="font-mono text-slate-500 truncate">
                          {approval?.signatureCode || meta.stampCode}
                        </span>
                        <span className="text-slate-500 font-mono">
                          {approval?.approvedAt ? new Date(approval.approvedAt).toLocaleDateString() : 'Signed'}
                        </span>
                      </>
                    ) : isHold ? (
                      <span className="text-rose-600 font-semibold text-[11px]">
                        {approval?.holds.length} liability unresolved
                      </span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">Awaiting officer review</span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Settle Hold Modal */}
      {selectedHold && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold">Settle University Liability</h4>
              </div>
              <button
                onClick={() => setSelectedHold(null)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleResolveSubmit} className="p-5 space-y-4">
              <div>
                <div className="text-xs text-slate-500 font-medium">Department</div>
                <div className="text-sm font-bold text-slate-900">{selectedHold.deptName}</div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                <div className="text-xs text-slate-500 font-medium">Liability Item</div>
                <div className="text-xs font-bold text-slate-900 mt-0.5">{selectedHold.hold.item}</div>
                {selectedHold.hold.amountETB && (
                  <div className="mt-2 text-base font-mono font-bold text-rose-700">
                    Amount: {selectedHold.hold.amountETB} ETB
                  </div>
                )}
                <div className="text-[11px] text-slate-600 mt-1">{selectedHold.hold.instructions}</div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Settlement Method
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Telebirr', 'CBE Birr', 'Physical Return'] as const).map((method) => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`px-2.5 py-1.5 text-xs font-semibold rounded-lg border text-center transition-colors cursor-pointer ${
                        paymentMethod === method
                          ? 'border-slate-900 bg-slate-900 text-white'
                          : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {paymentMethod === 'Physical Return'
                    ? 'Circulation / Officer Return Slip No.'
                    : `${paymentMethod} Transaction Reference ID`}
                </label>
                <input
                  type="text"
                  placeholder={
                    paymentMethod === 'Physical Return'
                      ? 'e.g., RET-DADU-2026-904'
                      : 'e.g., TXN-9984128491 (Leave blank to auto-generate simulated txn)'
                  }
                  value={receiptCode}
                  onChange={(e) => setReceiptCode(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedHold(null)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Close
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingHold}
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingHold ? 'Reconciling...' : 'Confirm Settlement'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* New Clearance Application Modal */}
      {isApplyModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-lg w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold">Initiate University Clearance Application</h4>
              </div>
              <button
                onClick={() => setIsApplyModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleCreateClearance} className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <span className="font-semibold text-slate-700">Applicant: </span>
                <span className="font-bold text-slate-950">{currentStudent.fullName}</span> (
                <span className="font-mono">{currentStudent.studentId}</span>)
                <div className="text-slate-500 mt-0.5">{currentStudent.department} · {currentStudent.college}</div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Clearance Purpose & Type
                </label>
                <select
                  value={newClearanceType}
                  onChange={(e) => {
                    const val = e.target.value as ClearanceType;
                    setNewClearanceType(val);
                    if (val === 'VACATION_EXIT') {
                      setNewReason('Semester break vacation travel & luggage clearance (Boqonnaaf Gibiidhaa Ba\'uu)');
                    } else if (val === 'LOST_ID_REPLACEMENT') {
                      setNewReason('Lost Student ID Card multi-sector clearance and replacement card reissuance');
                    } else if (val === 'GRADUATION') {
                      setNewReason('Final graduation clearance for degree issuance');
                    }
                  }}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-medium"
                >
                  <option value="VACATION_EXIT">
                    🧳 Vacation & Campus Exit Pass (Boqonnaaf Gibiidhaa Ba'uu)
                  </option>
                  <option value="LOST_ID_REPLACEMENT">
                    💳 Lost Student ID Card Replacement Clearance
                  </option>
                  <option value="GRADUATION">
                    🎓 Graduation Clearance (Final Degree Release)
                  </option>
                  <option value="END_OF_YEAR">
                    📅 End-of-Academic-Year Break Clearance
                  </option>
                  <option value="WITHDRAWAL">
                    🚪 Official University Withdrawal
                  </option>
                  <option value="TRANSFER">
                    🔄 Transfer to Another University
                  </option>
                </select>
              </div>

              {/* Dynamic Inputs for VACATION_EXIT */}
              {newClearanceType === 'VACATION_EXIT' && (
                <div className="p-3.5 bg-emerald-50/70 border border-emerald-200 rounded-lg space-y-3">
                  <div className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                    <Luggage className="w-4 h-4 text-emerald-700" />
                    Vacation Travel & Luggage Inspection Details
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      Travel Destination Town (Magaalaa Itti Deemtan)
                    </label>
                    <input
                      type="text"
                      value={destinationTown}
                      onChange={(e) => setDestinationTown(e.target.value)}
                      placeholder="e.g. Nekemte, Addis Ababa, Jimma, Dembi Dolo, Gimbi, Beddele"
                      className="w-full px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden focus:border-emerald-700"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                        Departure Date
                      </label>
                      <input
                        type="date"
                        value={departureDate}
                        onChange={(e) => setDepartureDate(e.target.value)}
                        className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                        Expected Return Date
                      </label>
                      <input
                        type="date"
                        value={expectedReturnDate}
                        onChange={(e) => setExpectedReturnDate(e.target.value)}
                        className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <div className="text-[11px] text-emerald-800 leading-tight">
                    * Dormitory room key return hold will be automatically assigned to Block Proctor.
                  </div>
                </div>
              )}

              {/* Dynamic Inputs for LOST_ID_REPLACEMENT */}
              {newClearanceType === 'LOST_ID_REPLACEMENT' && (
                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-lg space-y-3">
                  <div className="text-xs font-bold text-amber-950 flex items-center gap-1.5">
                    <IdCard className="w-4 h-4 text-amber-700" />
                    Lost ID Card Incident Information
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                        Police Incident Report #
                      </label>
                      <input
                        type="text"
                        value={policeReportNo}
                        onChange={(e) => setPoliceReportNo(e.target.value)}
                        placeholder="e.g. DaDU-POL-2026-8812"
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-700 mb-0.5">
                        Approximate Loss Location
                      </label>
                      <input
                        type="text"
                        value={incidentLocation}
                        onChange={(e) => setIncidentLocation(e.target.value)}
                        placeholder="e.g. Main Dining Plaza"
                        className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:outline-hidden"
                      />
                    </div>
                  </div>
                  <div className="text-[11px] text-amber-800 leading-tight">
                    * Automatic 150 ETB card replacement fee hold will be registered with Finance Directorate. Meal barcode deactivation will be broadcast to Cafeteria.
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year</label>
                  <input
                    type="text"
                    value={newAcademicYear}
                    onChange={(e) => setNewAcademicYear(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Semester</label>
                  <select
                    value={newSemester}
                    onChange={(e) => setNewSemester(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                  >
                    <option value="I">Semester I</option>
                    <option value="II">Semester II</option>
                    <option value="Summer">Kiremt / Summer</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Reason & Remarks
                </label>
                <textarea
                  rows={2}
                  value={newReason}
                  onChange={(e) => setNewReason(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                  placeholder="State the purpose of this clearance..."
                />
              </div>

              <div className="text-[11px] text-slate-500 leading-normal">
                Submitting this form broadcasts an electronic clearance request to all designated university directorates simultaneously.
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsApplyModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  Submit Application
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Vacation & Luggage Exit Gate Pass Modal */}
      {isVacationModalOpen && currentRequest && (
        <VacationGatePassModal
          request={currentRequest}
          onClose={() => setIsVacationModalOpen(false)}
        />
      )}

      {/* Lost ID Replacement & Multi-Sector Clearance Modal */}
      {isReplacementIdModalOpen && currentRequest && (
        <ReplacementIdCardModal
          request={currentRequest}
          onClose={() => setIsReplacementIdModalOpen(false)}
        />
      )}
    </div>
  );
};
