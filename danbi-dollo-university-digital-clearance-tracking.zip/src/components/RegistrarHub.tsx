import React, { useState } from 'react';
import { useClearance } from '../context/ClearanceContext';
import { ClearanceRequest, ClearanceStatus, DepartmentKey } from '../types/clearance';
import { DEPARTMENTS_METADATA } from '../data/mockData';
import {
  Award,
  CheckCircle2,
  Clock,
  Download,
  FileSpreadsheet,
  GraduationCap,
  History,
  Layers,
  Search,
  ShieldAlert,
  ShieldCheck,
  TrendingUp,
  UserCheck,
} from 'lucide-react';

interface Props {
  onOpenCertificateFor: (req: ClearanceRequest) => void;
}

export const RegistrarHub: React.FC<Props> = ({ onOpenCertificateFor }) => {
  const { requests, registrarFinalApproval, issueReplacementId, authorizeVacationGateExit } = useClearance();

  const [searchQuery, setSearchQuery] = useState('');
  const [collegeFilter, setCollegeFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState<ClearanceStatus | 'ALL'>('ALL');

  // Compute metrics
  const totalApps = requests.length;
  const fullyClearedApps = requests.filter((r) => r.finalCertificateIssued || r.overallStatus === 'APPROVED').length;
  const clearanceRate = totalApps > 0 ? Math.round((fullyClearedApps / totalApps) * 100) : 0;

  // Active holds and fines
  let totalActiveHoldsCount = 0;
  let totalFinesETB = 0;
  requests.forEach((r) => {
    Object.values(r.departments).forEach((d) => {
      d.holds.forEach((h) => {
        if (!h.resolved) {
          totalActiveHoldsCount += 1;
          if (h.amountETB) totalFinesETB += h.amountETB;
        }
      });
    });
  });

  // Calculate bottleneck by department
  const departmentPendingStats = (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).map((key) => {
    const meta = DEPARTMENTS_METADATA[key];
    const pendingCount = requests.filter((r) => r.departments[key]?.status === 'PENDING').length;
    const holdCount = requests.filter((r) => r.departments[key]?.status === 'HOLD').length;
    return {
      key,
      name: meta.name,
      pendingCount,
      holdCount,
      totalHoldAndPending: pendingCount + holdCount,
    };
  });

  // Unique colleges for filter
  const uniqueColleges = Array.from(new Set(requests.map((r) => r.student.college)));

  // Filter requests
  const filteredRequests = requests.filter((req) => {
    const matchesSearch =
      req.student.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      req.student.department.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCollege = collegeFilter === 'ALL' || req.student.college === collegeFilter;
    const matchesStatus = statusFilter === 'ALL' || req.overallStatus === statusFilter;

    return matchesSearch && matchesCollege && matchesStatus;
  });

  // Export CSV handler
  const handleExportCSV = () => {
    const headers = [
      'Student ID',
      'Full Name',
      'College',
      'Department',
      'Program',
      'Clearance Type',
      'Overall Status',
      'Certificate Serial',
      'Date Initiated',
      'Date Cleared',
    ];

    const rows = filteredRequests.map((r) => [
      r.student.studentId,
      `"${r.student.fullName}"`,
      `"${r.student.college}"`,
      `"${r.student.department}"`,
      r.student.program,
      r.clearanceType,
      r.overallStatus,
      r.certificateSerial || 'N/A',
      r.dateInitiated ? new Date(r.dateInitiated).toLocaleDateString() : '',
      r.certificateIssueDate ? new Date(r.certificateIssueDate).toLocaleDateString() : '',
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `dadu_clearance_manifest_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Recent audit trail
  const allAudits = requests
    .flatMap((r) => r.auditLog.map((a) => ({ ...a, studentName: r.student.fullName })))
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    .slice(0, 8);

  return (
    <div className="space-y-6">
      {/* Executive Overview Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Central Administration
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs font-semibold text-slate-700">University Registrar Directorate</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-0.5">
              Office of the University Registrar & Alumni Directorate
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Danbi Dollo University graduation credentials clearance verification, institutional oversight & audit ledger.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportCSV}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV Manifest
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-medium text-slate-500">Total Applications</div>
          <div className="text-2xl font-extrabold text-slate-950 font-mono mt-1">{totalApps}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Academic Cohort 2026</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-medium text-slate-500">Completion Rate</div>
          <div className="text-2xl font-extrabold text-emerald-700 font-mono mt-1">{clearanceRate}%</div>
          <div className="text-[11px] text-emerald-700 mt-0.5 font-medium">{fullyClearedApps} of {totalApps} cleared</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-medium text-slate-500">Unsettled Liabilities</div>
          <div className="text-2xl font-extrabold text-rose-700 font-mono mt-1">{totalActiveHoldsCount}</div>
          <div className="text-[11px] text-rose-600 mt-0.5 font-medium">Items awaiting resolution</div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs">
          <div className="text-xs font-medium text-slate-500">Liabilities Valuation</div>
          <div className="text-2xl font-extrabold text-slate-950 font-mono mt-1">{totalFinesETB} <span className="text-xs font-sans font-normal text-slate-500">ETB</span></div>
          <div className="text-[11px] text-slate-400 mt-0.5">Penalties & item replacements</div>
        </div>
      </div>

      {/* Department Bottlenecks Breakdown */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">Departmental Clearance Velocity & Bottlenecks</h3>
            <p className="text-xs text-slate-500">Real-time load and open queues across the 9 administrative offices.</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {departmentPendingStats.map((item) => (
            <div key={item.key} className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-800 truncate">{item.name.split(' ')[0]} {item.name.split(' ')[1] || ''}</span>
                {item.holdCount > 0 ? (
                  <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-100 text-rose-700">
                    {item.holdCount} Holds
                  </span>
                ) : (
                  <span className="font-mono text-[10px] text-slate-400">0 Holds</span>
                )}
              </div>
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-slate-200/60 text-[11px] text-slate-500">
                <span>Pending Review:</span>
                <span className="font-mono font-bold text-slate-900">{item.pendingCount} students</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Master Clearance Registry Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        {/* Table Controls */}
        <div className="p-4 border-b border-slate-200 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 bg-slate-50/50">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search student ID, name, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-slate-900"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={collegeFilter}
              onChange={(e) => setCollegeFilter(e.target.value)}
              className="px-2.5 py-1 text-xs bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Colleges</option>
              {uniqueColleges.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-2.5 py-1 text-xs bg-white border border-slate-200 rounded-md text-slate-700 focus:outline-hidden"
            >
              <option value="ALL">All Statuses</option>
              <option value="APPROVED">Approved & Cleared</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="ACTION_REQUIRED">Action Required / Holds</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/75 text-slate-600 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Student Name & ID</th>
                <th className="px-4 py-3">College & Department</th>
                <th className="px-4 py-3">Progress</th>
                <th className="px-4 py-3">Overall Status</th>
                <th className="px-4 py-3">Official Certificate</th>
                <th className="px-4 py-3 text-right">Registrar Sign-Off</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRequests.map((req) => {
                const preRegistrarKeys = (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).filter(
                  (k) => k !== 'registrar'
                );
                const clearedCount = preRegistrarKeys.filter(
                  (k) => req.departments[k]?.status === 'CLEARED'
                ).length;
                const canFinalApprove =
                  clearedCount === preRegistrarKeys.length && !req.finalCertificateIssued;

                return (
                  <tr key={req.id} className="hover:bg-slate-50/75 transition-colors">
                    <td className="px-4 py-3.5">
                      <div className="flex items-center gap-3">
                        <img
                          src={req.student.avatarUrl}
                          alt={req.student.fullName}
                          className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                          referrerPolicy="no-referrer"
                        />
                        <div>
                          <div className="font-bold text-slate-900">{req.student.fullName}</div>
                          <div className="font-mono text-slate-500 text-[11px]">{req.student.studentId}</div>
                        </div>
                      </div>
                    </td>

                    <td className="px-4 py-3.5">
                      <div className="font-semibold text-slate-900">{req.student.department}</div>
                      <div className="text-[11px] text-slate-500">{req.student.college}</div>
                    </td>

                    <td className="px-4 py-3.5 font-mono">
                      <span className="font-bold text-slate-900">{clearedCount}/8</span>{' '}
                      <span className="text-slate-400">Offices Cleared</span>
                    </td>

                    <td className="px-4 py-3.5">
                      {req.overallStatus === 'APPROVED' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Approved
                        </span>
                      ) : req.overallStatus === 'ACTION_REQUIRED' ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                          <ShieldAlert className="w-3 h-3 text-rose-600" />
                          Holds Pending
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                          <Clock className="w-3 h-3 text-amber-600" />
                          In Progress
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3.5">
                      {req.finalCertificateIssued ? (
                        <button
                          onClick={() => onOpenCertificateFor(req)}
                          className="inline-flex items-center gap-1 text-slate-900 hover:text-amber-700 font-mono font-bold text-xs cursor-pointer"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                          <span>{req.certificateSerial}</span>
                        </button>
                      ) : (
                        <span className="text-slate-400 text-xs italic">Not issued yet</span>
                      )}
                    </td>

                    <td className="px-4 py-3.5 text-right whitespace-nowrap">
                      {req.finalCertificateIssued ? (
                        <button
                          onClick={() => onOpenCertificateFor(req)}
                          className="px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-md transition-colors cursor-pointer"
                        >
                          {req.clearanceType === 'VACATION_EXIT'
                            ? 'View Gate Pass'
                            : req.clearanceType === 'LOST_ID_REPLACEMENT'
                            ? 'View Replacement ID'
                            : 'View Certificate'}
                        </button>
                      ) : canFinalApprove ? (
                        <button
                          onClick={() => {
                            if (req.clearanceType === 'LOST_ID_REPLACEMENT') {
                              issueReplacementId(req.id);
                            } else if (req.clearanceType === 'VACATION_EXIT') {
                              authorizeVacationGateExit(req.id);
                            } else {
                              registrarFinalApproval(req.id);
                            }
                          }}
                          className="px-3 py-1 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer"
                        >
                          {req.clearanceType === 'LOST_ID_REPLACEMENT'
                            ? 'Issue Replacement ID'
                            : req.clearanceType === 'VACATION_EXIT'
                            ? 'Authorize Gate Pass'
                            : 'Authorize & Release'}
                        </button>
                      ) : (
                        <span className="text-xs text-slate-400">
                          Awaiting {preRegistrarKeys.length - clearedCount} Offices
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Audit Log Stream */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <History className="w-4 h-4 text-slate-600" />
          <h3 className="text-sm font-bold text-slate-900">Institutional Activity & Audit Ledger</h3>
        </div>

        <div className="divide-y divide-slate-100">
          {allAudits.map((item) => (
            <div key={item.id} className="py-2.5 flex items-start justify-between gap-4 text-xs">
              <div>
                <span className="font-bold text-slate-900">{item.actor}</span>
                <span className="text-slate-400 mx-1.5">·</span>
                <span className="font-semibold text-slate-700">{item.action}</span>
                {item.studentName && (
                  <span className="text-slate-500"> for {item.studentName}</span>
                )}
                {item.note && <div className="text-slate-500 mt-0.5">{item.note}</div>}
              </div>
              <span className="font-mono text-slate-400 shrink-0 text-[11px]">
                {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
