import React from 'react';
import { ClearanceRequest } from '../types/clearance';
import { DADU_EMBLEM_URL } from '../data/mockData';
import { useClearance } from '../context/ClearanceContext';
import {
  CheckCircle2,
  Clock,
  Download,
  Luggage,
  MapPin,
  Printer,
  QrCode,
  ShieldAlert,
  ShieldCheck,
  X,
} from 'lucide-react';

interface Props {
  request: ClearanceRequest;
  onClose: () => void;
}

export const VacationGatePassModal: React.FC<Props> = ({ request, onClose }) => {
  const { authorizeVacationGateExit } = useClearance();

  const handlePrint = () => {
    window.print();
  };

  const student = request.student;
  const vacation = request.vacationExitPass || {
    destinationTown: 'Nekemte',
    departureDate: '2026-10-28',
    expectedReturnDate: '2026-11-20',
    luggagePermitIssued: true,
    gateSecurityExitCleared: false,
  };

  const isDormCleared = request.departments.dormitory?.status === 'CLEARED';
  const isLibraryCleared = request.departments.library?.status === 'CLEARED';
  const isCafeteriaCleared = request.departments.cafeteria?.status === 'CLEARED';
  const isGateSecurityCleared = vacation.gateSecurityExitCleared || request.departments.campus_police?.status === 'CLEARED';

  const passSerial = request.certificateSerial || `DaDU-VAC-GATE-${student.studentId.replace(/[^a-zA-Z0-9]/g, '')}`;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Top Control Bar (Hidden when printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 bg-emerald-950 text-white border-b border-emerald-900">
          <div className="flex items-center gap-3">
            <Luggage className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="text-sm font-semibold tracking-wide">
                Campus Vacation & Luggage Exit Pass
              </h3>
              <p className="text-xs text-emerald-300">
                Danbi Dollo University · Campus Security & Student Services Directorate
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {!isGateSecurityCleared && (
              <button
                onClick={() => authorizeVacationGateExit(request.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-emerald-950 bg-emerald-400 hover:bg-emerald-300 rounded-md transition-colors shadow-xs cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                Authorize Gate Departure
              </button>
            )}
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Pass Area */}
        <div id="printable-certificate" className="p-8 sm:p-12 bg-white text-slate-900">
          <div className="relative border-4 border-double border-emerald-900 p-8 sm:p-10 rounded-sm">
            {/* Header Lockup */}
            <div className="flex flex-col items-center text-center pb-6 border-b-2 border-emerald-950">
              <div className="flex items-center justify-center gap-6 mb-3">
                <img
                  src={DADU_EMBLEM_URL}
                  alt="Dambi Dollo University Official Logo"
                  className="w-24 h-24 object-contain"
                  referrerPolicy="no-referrer"
                />
                <div className="text-center">
                  <div className="text-xs font-semibold tracking-wider text-slate-700 uppercase">
                    Federal Democratic Republic of Ethiopia · Ministry of Education
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-emerald-950 uppercase mt-0.5">
                    DANBI DOLLO UNIVERSITY
                  </h1>
                  <div className="text-sm font-semibold text-slate-800">
                    Student Services & Campus Security Directorate
                  </div>
                  <div className="text-xs text-slate-600 mt-1 font-mono">
                    Official Vacation Departure & Luggage Exit Permit · Dembi Dolo, Ethiopia
                  </div>
                </div>
              </div>

              <div className="inline-block px-4 py-1.5 bg-emerald-100 border border-emerald-700 rounded-sm text-xs font-extrabold tracking-widest uppercase text-emerald-950 mt-2">
                OFFICIAL VACATION CAMPUS EXIT & LUGGAGE PASS
              </div>
            </div>

            {/* Pass Metadata */}
            <div className="flex flex-wrap items-center justify-between gap-4 py-3 border-b border-slate-300 text-xs text-slate-700">
              <div>
                <span className="font-semibold text-slate-900">Gate Pass Serial:</span>{' '}
                <span className="font-mono font-bold text-emerald-950">{passSerial}</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900">Academic Year:</span>{' '}
                <span className="font-mono">{request.academicYear} (Semester {request.semester})</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900">Departure Date:</span>{' '}
                <span className="font-mono font-bold">{vacation.departureDate}</span>
              </div>
            </div>

            {/* Student & Destination Details Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 my-6 p-4 bg-slate-50 border border-slate-200 rounded-md">
              <div className="space-y-2">
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Student Information
                </div>
                <div className="text-base font-bold text-slate-950">{student.fullName}</div>
                <div className="text-xs font-mono text-slate-700 font-semibold">{student.studentId}</div>
                <div className="text-xs text-slate-600">{student.department}</div>
                <div className="text-xs text-slate-600">
                  {student.dormBlock || 'Dorm Block'}, {student.dormRoom || 'Room'}
                </div>
              </div>

              <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-200 md:pl-6">
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Travel & Vacation Destination
                </div>
                <div className="flex items-center gap-1.5 text-base font-bold text-emerald-950">
                  <MapPin className="w-4 h-4 text-emerald-700 shrink-0" />
                  {vacation.destinationTown}
                </div>
                <div className="text-xs text-slate-700">
                  <span className="font-semibold">Exit Date:</span> {vacation.departureDate}
                </div>
                <div className="text-xs text-slate-700">
                  <span className="font-semibold">Expected Return:</span> {vacation.expectedReturnDate}
                </div>
                <div className="text-xs text-slate-500 italic">
                  Purpose: Semester Break & Family Vacation
                </div>
              </div>

              <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-200 md:pl-6">
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Luggage & Property Inspection
                </div>
                <div className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-900">
                  <Luggage className="w-3.5 h-3.5" />
                  Permit Authorized
                </div>
                <ul className="text-xs text-slate-700 space-y-1 list-disc list-inside">
                  <li>Personal Suitcase / Travel Bag</li>
                  <li>Academic Notebooks & Study Textbooks</li>
                  <li>Registered Laptop / Calculator</li>
                </ul>
                <div className="text-[10px] text-slate-500">
                  Strictly verified: No unauthorized university property, library materials, or lab equipment.
                </div>
              </div>
            </div>

            {/* Critical Sector Clearance Verifications */}
            <div className="my-6">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                Pre-Departure Sector Clearances
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                {/* 1. Dormitory */}
                <div
                  className={`p-3 rounded border ${
                    isDormCleared ? 'bg-emerald-50/50 border-emerald-300' : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">1. Dormitory / Proctor</span>
                    {isDormCleared ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {isDormCleared ? 'Room key surrendered & closet locked.' : 'Room key surrender required.'}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 mt-2">
                    {request.departments.dormitory.signatureCode || 'PENDING'}
                  </div>
                </div>

                {/* 2. Library */}
                <div
                  className={`p-3 rounded border ${
                    isLibraryCleared ? 'bg-emerald-50/50 border-emerald-300' : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">2. University Library</span>
                    {isLibraryCleared ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {isLibraryCleared ? 'All borrowed books returned.' : 'Overdue books must be returned.'}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 mt-2">
                    {request.departments.library.signatureCode || 'PENDING'}
                  </div>
                </div>

                {/* 3. Cafeteria */}
                <div
                  className={`p-3 rounded border ${
                    isCafeteriaCleared ? 'bg-emerald-50/50 border-emerald-300' : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">3. Dining Hall</span>
                    {isCafeteriaCleared ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {isCafeteriaCleared ? 'Meal barcode frozen for break.' : 'Pending dining freeze.'}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 mt-2">
                    {request.departments.cafeteria.signatureCode || 'PENDING'}
                  </div>
                </div>

                {/* 4. Campus Police Gate */}
                <div
                  className={`p-3 rounded border ${
                    isGateSecurityCleared ? 'bg-emerald-50/50 border-emerald-300' : 'bg-amber-50 border-amber-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-bold text-slate-900">4. Main Gate Security</span>
                    {isGateSecurityCleared ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Clock className="w-4 h-4 text-amber-600" />
                    )}
                  </div>
                  <div className="text-[11px] text-slate-600">
                    {isGateSecurityCleared ? 'Luggage inspected. Exit passed.' : 'Awaiting physical gate check.'}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 mt-2">
                    {request.departments.campus_police.signatureCode || 'PENDING'}
                  </div>
                </div>
              </div>
            </div>

            {/* Official Stamps & Signatures Footer */}
            <div className="pt-6 border-t border-slate-300 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-xs">
              <div className="space-y-1">
                <div className="font-serif italic font-bold text-slate-800 text-sm">
                  {request.departments.dormitory.officerName}
                </div>
                <div className="text-slate-600">Chief Dormitory Proctor</div>
                <div className="font-mono text-[10px] text-slate-500">
                  Room Key & Inventory Cleared
                </div>
              </div>

              <div className="space-y-1">
                <div className="font-serif italic font-bold text-slate-800 text-sm">
                  {request.departments.campus_police.officerName}
                </div>
                <div className="text-slate-600">Head of University Security</div>
                <div className="font-mono text-[10px] text-slate-500">
                  Main Gate Luggage & Exit Commander
                </div>
              </div>

              <div className="flex flex-col items-center justify-center">
                <div className="w-20 h-20 border-2 border-emerald-800 rounded bg-white p-1 shadow-xs flex flex-col items-center justify-center">
                  <QrCode className="w-12 h-12 text-emerald-950" />
                  <span className="text-[8px] font-mono font-bold text-slate-600 mt-0.5">GATE VALID</span>
                </div>
                <div className="text-[9px] font-mono text-slate-500 mt-1">
                  Token: {request.qrValidationToken.slice(0, 16)}...
                </div>
              </div>
            </div>

            {/* Bottom Disclaimer */}
            <div className="mt-6 pt-4 border-t border-slate-200 text-center text-[10px] text-slate-500">
              Notice: This gate pass is strictly non-transferable and must be presented alongside valid student credentials at Danbi Dollo University Main Exit Gate.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
