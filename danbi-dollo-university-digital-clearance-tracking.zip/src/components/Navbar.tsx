import React from 'react';
import { useClearance } from '../context/ClearanceContext';
import { UserRole } from '../types/clearance';
import { DADU_EMBLEM_URL } from '../data/mockData';
import { CheckCircle2, ShieldCheck, UserCheck, RefreshCw, Download } from 'lucide-react';

interface Props {
  activeTab: 'student' | 'department' | 'registrar' | 'verify' | 'guide';
  setActiveTab: (tab: 'student' | 'department' | 'registrar' | 'verify' | 'guide') => void;
  onOpenCertificate?: () => void;
  onOpenAuthModal?: () => void;
}

export const Navbar: React.FC<Props> = ({
  activeTab,
  setActiveTab,
  onOpenCertificate,
  onOpenAuthModal,
}) => {
  const { currentRole, setCurrentRole, currentRequest, currentUser, logout, resetToDemoData } = useClearance();

  const handleRoleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const role = e.target.value as UserRole;
    setCurrentRole(role);
    if (role === 'STUDENT') setActiveTab('student');
    if (role === 'DEPARTMENT_OFFICER') setActiveTab('department');
    if (role === 'REGISTRAR') setActiveTab('registrar');
    if (role === 'SECURITY_VERIFIER') setActiveTab('verify');
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-8 px-4 sm:px-6 py-3">
        {/* Zone 1: Single Brand element */}
        <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
          <img
            src={DADU_EMBLEM_URL}
            alt="Dambi Dollo University Official Logo"
            className="w-10 h-10 object-contain drop-shadow-xs"
            referrerPolicy="no-referrer"
          />
          <button
            onClick={() => setActiveTab('student')}
            className="text-left cursor-pointer focus:outline-hidden"
          >
            <span className="text-base font-bold tracking-tight text-slate-900 block leading-tight">
              Danbi Dollo University
            </span>
            <span className="text-[11px] font-medium text-slate-500 block leading-none">
              Digital Clearance System
            </span>
          </button>
        </div>

        {/* Zone 2: 4-5 Clean single-line text links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-600">
          <button
            onClick={() => {
              setActiveTab('student');
              setCurrentRole('STUDENT');
            }}
            className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'student'
                ? 'border-slate-900 text-slate-950 font-bold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Student Tracker
          </button>
          <button
            onClick={() => {
              setActiveTab('department');
              setCurrentRole('DEPARTMENT_OFFICER');
            }}
            className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'department'
                ? 'border-slate-900 text-slate-950 font-bold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Department Desks
          </button>
          <button
            onClick={() => {
              setActiveTab('registrar');
              setCurrentRole('REGISTRAR');
            }}
            className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'registrar'
                ? 'border-slate-900 text-slate-950 font-bold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Registrar Hub
          </button>
          <button
            onClick={() => {
              setActiveTab('verify');
              setCurrentRole('SECURITY_VERIFIER');
            }}
            className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'verify'
                ? 'border-slate-900 text-slate-950 font-bold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Verify Certificate
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 transition-colors cursor-pointer ${
              activeTab === 'guide'
                ? 'border-slate-900 text-slate-950 font-bold'
                : 'border-transparent hover:text-slate-900 hover:border-slate-300'
            }`}
          >
            Clearance Guide
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action Area */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {currentUser ? (
            <div className="flex items-center gap-2 text-xs">
              <div className="hidden lg:flex items-center gap-1.5 pl-2 border-l border-slate-200">
                <span className="font-bold text-slate-900 truncate max-w-[130px]">
                  {currentUser.fullName.split(' ')[0]}
                </span>
                <span className="font-mono text-slate-500 text-[11px]">
                  ({currentUser.studentId})
                </span>
              </div>
              <button
                onClick={logout}
                title="Log out of student account"
                className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
              >
                <span>Log Out</span>
              </button>
            </div>
          ) : (
            onOpenAuthModal && (
              <button
                onClick={onOpenAuthModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer shadow-xs"
              >
                <span>Log In / Register</span>
              </button>
            )
          )}

          <div className="hidden sm:flex items-center gap-1.5 bg-slate-100 rounded-lg p-1 text-xs">
            <span className="text-slate-500 pl-1.5">Role:</span>
            <select
              value={currentRole}
              onChange={handleRoleChange}
              className="bg-transparent font-semibold text-slate-800 text-xs py-1 px-1.5 rounded focus:outline-hidden cursor-pointer"
            >
              <option value="STUDENT">Student</option>
              <option value="DEPARTMENT_OFFICER">Department Officer</option>
              <option value="REGISTRAR">University Registrar</option>
              <option value="SECURITY_VERIFIER">Security / Gate Verifier</option>
            </select>
          </div>

          {currentRequest?.finalCertificateIssued && onOpenCertificate && (
            <button
              onClick={onOpenCertificate}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              View Slip
            </button>
          )}

          <button
            onClick={() => setActiveTab('guide')}
            title="Download XAMPP Package & Setup Guide"
            className="hidden lg:inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>XAMPP Package</span>
          </button>

          <button
            onClick={resetToDemoData}
            title="Reset demo data"
            className="p-1.5 text-slate-500 hover:text-slate-900 rounded-md hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile nav subrow */}
      <div className="flex md:hidden overflow-x-auto px-4 py-2 border-t border-slate-200 gap-4 text-xs font-semibold text-slate-600">
        <button
          onClick={() => {
            setActiveTab('student');
            setCurrentRole('STUDENT');
          }}
          className={activeTab === 'student' ? 'text-slate-900 font-bold whitespace-nowrap' : 'whitespace-nowrap'}
        >
          Student
        </button>
        <button
          onClick={() => {
            setActiveTab('department');
            setCurrentRole('DEPARTMENT_OFFICER');
          }}
          className={activeTab === 'department' ? 'text-slate-900 font-bold whitespace-nowrap' : 'whitespace-nowrap'}
        >
          Departments
        </button>
        <button
          onClick={() => {
            setActiveTab('registrar');
            setCurrentRole('REGISTRAR');
          }}
          className={activeTab === 'registrar' ? 'text-slate-900 font-bold whitespace-nowrap' : 'whitespace-nowrap'}
        >
          Registrar
        </button>
        <button
          onClick={() => {
            setActiveTab('verify');
            setCurrentRole('SECURITY_VERIFIER');
          }}
          className={activeTab === 'verify' ? 'text-slate-900 font-bold whitespace-nowrap' : 'whitespace-nowrap'}
        >
          Verify
        </button>
        <button
          onClick={() => setActiveTab('guide')}
          className={activeTab === 'guide' ? 'text-slate-900 font-bold whitespace-nowrap' : 'whitespace-nowrap'}
        >
          Guide
        </button>
      </div>
    </header>
  );
};
