import React, { useState } from 'react';
import { useClearance } from '../context/ClearanceContext';
import { DADU_EMBLEM_URL } from '../data/mockData';
import {
  CheckCircle2,
  FileCheck2,
  GraduationCap,
  QrCode,
  Search,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  XCircle,
} from 'lucide-react';

export const VerifyCertificate: React.FC = () => {
  const { requests } = useClearance();

  // Search input: prefill with Tolosa's serial as an immediate example
  const [query, setQuery] = useState('DaDU-CLR-2026-0842');
  const [hasSearched, setHasSearched] = useState(true);

  // Perform search
  const cleanQuery = query.trim().toLowerCase();
  const matchedRequest = requests.find((r) => {
    if (!cleanQuery) return false;
    return (
      r.certificateSerial?.toLowerCase() === cleanQuery ||
      r.qrValidationToken.toLowerCase() === cleanQuery ||
      r.student.studentId.toLowerCase() === cleanQuery ||
      r.id.toLowerCase() === cleanQuery
    );
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setHasSearched(true);
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Search Header */}
      <div className="bg-white border border-slate-200 rounded-xl p-6 text-center shadow-xs">
        <div className="mb-3 flex justify-center">
          <img
            src={DADU_EMBLEM_URL}
            alt="Dambi Dollo University Official Logo"
            className="w-14 h-14 object-contain drop-shadow-xs"
            referrerPolicy="no-referrer"
          />
        </div>
        <h2 className="text-xl font-bold text-slate-900">
          Danbi Dollo University Clearance Verification Portal
        </h2>
        <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-5">
          Public and campus security verification system for student clearance certificates, gate passes, and graduation releases.
        </p>

        <form onSubmit={handleSearch} className="flex gap-2 max-w-md mx-auto">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Enter Certificate Serial or Student ID..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer shrink-0"
          >
            Verify Credential
          </button>
        </form>

        {/* Quick sample chips */}
        <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-xs text-slate-500">
          <span>Try sample:</span>
          <button
            type="button"
            onClick={() => {
              setQuery('DaDU-CLR-2026-0842');
              setHasSearched(true);
            }}
            className="text-slate-900 underline font-mono cursor-pointer hover:text-amber-700"
          >
            DaDU-CLR-2026-0842 (Graduation)
          </button>
          <span>·</span>
          <button
            type="button"
            onClick={() => {
              setQuery('DaDU/UGR/1589/14');
              setHasSearched(true);
            }}
            className="text-emerald-800 underline font-mono cursor-pointer hover:text-emerald-950 font-semibold"
          >
            DaDU/UGR/1589/14 (Vacation Exit)
          </button>
          <span>·</span>
          <button
            type="button"
            onClick={() => {
              setQuery('DaDU/UGR/1802/15');
              setHasSearched(true);
            }}
            className="text-amber-800 underline font-mono cursor-pointer hover:text-amber-950 font-semibold"
          >
            DaDU/UGR/1802/15 (Lost ID Clearance)
          </button>
        </div>
      </div>

      {/* Verification Result Card */}
      {hasSearched && (
        <div>
          {matchedRequest ? (
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
              {/* Banner Status */}
              <div
                className={`p-4 border-b flex items-center justify-between gap-4 ${
                  matchedRequest.finalCertificateIssued
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                    : 'bg-amber-50 border-amber-200 text-amber-900'
                }`}
              >
                <div className="flex items-center gap-3">
                  {matchedRequest.finalCertificateIssued ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  ) : (
                    <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0" />
                  )}
                  <div>
                    <h3 className="text-sm font-bold">
                      {matchedRequest.finalCertificateIssued
                        ? 'OFFICIALLY VERIFIED & ACTIVE CLEARANCE'
                        : 'CLEARANCE RECORD FOUND — CONDITIONAL / IN PROGRESS'}
                    </h3>
                    <p className="text-xs opacity-80">
                      {matchedRequest.finalCertificateIssued
                        ? 'Authenticated on the official Danbi Dollo University Registrar Ledger.'
                        : 'Application is still active. Final release has not been signed by the Registrar.'}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-xs font-mono font-bold block">
                    {matchedRequest.certificateSerial || 'STATUS: PENDING'}
                  </span>
                  <span className="text-[10px] uppercase tracking-wider block opacity-75">
                    {matchedRequest.clearanceType}
                  </span>
                </div>
              </div>

              {/* Student Details Grid */}
              <div className="p-6">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5 pb-6 border-b border-slate-100">
                  <img
                    src={matchedRequest.student.avatarUrl}
                    alt={matchedRequest.student.fullName}
                    className="w-20 h-20 rounded-lg object-cover border border-slate-200 shadow-xs shrink-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="space-y-1">
                    <h4 className="text-lg font-bold text-slate-900">
                      {matchedRequest.student.fullName}
                    </h4>
                    <div className="text-xs text-slate-600">
                      <span className="font-mono font-semibold">{matchedRequest.student.studentId}</span>
                      <span className="mx-2">·</span>
                      <span>{matchedRequest.student.program} Program</span>
                      <span className="mx-2">·</span>
                      <span>CGPA: <strong className="font-mono">{matchedRequest.student.cgpa}</strong></span>
                    </div>
                    <div className="text-xs text-slate-500">
                      {matchedRequest.student.department} · {matchedRequest.student.college}
                    </div>
                  </div>
                </div>

                {/* Security Verification Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-5 border-b border-slate-100 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Academic Year</span>
                    <strong className="text-slate-900 font-mono">{matchedRequest.academicYear} Sem {matchedRequest.semester}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Cost Sharing Bond</span>
                    <strong className="text-slate-900 font-mono">{matchedRequest.student.costSharingAgreementNo}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Authorization Date</span>
                    <strong className="text-slate-900 font-mono">
                      {matchedRequest.certificateIssueDate
                        ? new Date(matchedRequest.certificateIssueDate).toLocaleDateString()
                        : 'Awaiting Sign-off'}
                    </strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Campus Gate Pass</span>
                    <strong className={matchedRequest.finalCertificateIssued || matchedRequest.vacationExitPass?.gateSecurityExitCleared ? 'text-emerald-700' : 'text-amber-700'}>
                      {matchedRequest.finalCertificateIssued || matchedRequest.vacationExitPass?.gateSecurityExitCleared
                        ? 'Authorized (Exit Allowed)'
                        : 'Hold at Gate (Clearance Incomplete)'}
                    </strong>
                  </div>

                  {/* Vacation specific details */}
                  {matchedRequest.vacationExitPass && (
                    <div className="col-span-2 sm:col-span-3 p-2.5 bg-emerald-50 rounded border border-emerald-200 text-emerald-950">
                      <div className="font-bold flex items-center gap-1 text-[11px] uppercase tracking-wider text-emerald-900">
                        🧳 Vacation Exit & Luggage Pass
                      </div>
                      <div className="flex flex-wrap items-center gap-4 mt-1 text-xs">
                        <span>Destination: <strong>{matchedRequest.vacationExitPass.destinationTown}</strong></span>
                        <span>·</span>
                        <span>Departure: <strong>{matchedRequest.vacationExitPass.departureDate}</strong></span>
                        <span>·</span>
                        <span>Return: <strong>{matchedRequest.vacationExitPass.expectedReturnDate}</strong></span>
                        <span>·</span>
                        <span>Luggage: <strong className="text-emerald-800">Inspected & Permitted</strong></span>
                      </div>
                    </div>
                  )}

                  {/* Lost ID specific details */}
                  {matchedRequest.lostIdIncident && (
                    <div className="col-span-2 sm:col-span-3 p-2.5 bg-amber-50 rounded border border-amber-200 text-amber-950">
                      <div className="font-bold flex items-center gap-1 text-[11px] uppercase tracking-wider text-amber-900">
                        💳 Lost Student ID Clearance Audit
                      </div>
                      <div className="flex flex-wrap items-center gap-4 mt-1 text-xs">
                        <span>Police Incident #: <strong>{matchedRequest.lostIdIncident.policeReportNo}</strong></span>
                        <span>·</span>
                        <span>Meal Barcode: <strong className="text-emerald-800">Deactivated & Blocked</strong></span>
                        <span>·</span>
                        <span>Replacement Fee: <strong>150 ETB ({matchedRequest.lostIdIncident.replacementFeePaid ? 'PAID' : 'PENDING'})</strong></span>
                        {matchedRequest.lostIdIncident.replacementIdIssued && (
                          <>
                            <span>·</span>
                            <span>New ID Barcode: <strong className="font-mono text-emerald-900">{matchedRequest.lostIdIncident.newStudentIdBarcode}</strong></span>
                          </>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="col-span-2 sm:col-span-3">
                    <span className="text-slate-400 block text-[11px]">Cryptographic Token</span>
                    <span className="font-mono text-[11px] text-slate-700 break-all">
                      {matchedRequest.qrValidationToken}
                    </span>
                  </div>
                </div>

                {/* Directorate Summary Status */}
                <div className="pt-5">
                  <h5 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                    Sign-off Verification Ledger
                  </h5>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {Object.values(matchedRequest.departments).map((dept) => (
                      <div
                        key={dept.departmentId}
                        className="flex items-center justify-between p-2 bg-slate-50 rounded border border-slate-100"
                      >
                        <span className="font-medium text-slate-800 truncate mr-2">
                          {dept.departmentName.split(' ')[0]} {dept.departmentName.split(' ')[1] || ''}
                        </span>
                        <span
                          className={`font-mono text-[11px] font-semibold ${
                            dept.status === 'CLEARED'
                              ? 'text-emerald-700'
                              : dept.status === 'HOLD'
                              ? 'text-rose-700'
                              : 'text-amber-700'
                          }`}
                        >
                          {dept.status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white border border-slate-200 rounded-xl p-8 text-center shadow-xs">
              <XCircle className="w-10 h-10 text-rose-500 mx-auto mb-2" />
              <h3 className="text-base font-bold text-slate-900">No Record Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                No clearance certificate matching "{query}" exists in the Danbi Dollo University database. Please confirm the serial number.
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
