import React, { useState } from 'react';
import { DADU_CAMPUS_URL, DEPARTMENTS_METADATA } from '../data/mockData';
import { downloadXamppPackage } from '../utils/downloadXamppZip';
import {
  BookOpen,
  Building,
  CheckCircle,
  HelpCircle,
  Info,
  MapPin,
  Phone,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Download,
  Loader2,
  Code2,
} from 'lucide-react';

export const ClearanceGuide: React.FC = () => {
  const [downloading, setDownloading] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState<string | null>(null);

  const handleDownloadZip = async () => {
    setDownloading(true);
    setDownloadStatus('Starting download...');
    try {
      await downloadXamppPackage((status) => setDownloadStatus(status));
    } catch {
      setDownloadStatus('Error creating zip.');
    } finally {
      setTimeout(() => {
        setDownloading(false);
        setDownloadStatus(null);
      }, 3500);
    }
  };
  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Hero Banner */}
      <div className="relative rounded-xl overflow-hidden border border-slate-200 shadow-xs">
        <img
          src={DADU_CAMPUS_URL}
          alt="Danbi Dollo University Campus"
          className="w-full h-48 sm:h-64 object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-900/40 to-transparent flex flex-col justify-end p-6 text-white">
          <span className="text-xs font-semibold text-amber-300 tracking-wider uppercase">
            Official University Protocol
          </span>
          <h2 className="text-xl sm:text-2xl font-bold mt-1">
            Danbi Dollo University Digital Clearance Guide
          </h2>
          <p className="text-xs text-slate-300 mt-1 max-w-xl">
            Streamlining administrative property returns, cost-sharing audits, and graduation credential release across Dembi Dolo campus.
          </p>
        </div>
      </div>

      {/* 4 Step Process Overview */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 mb-4">4-Stage Digital Clearance Lifecycle</h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
              1
            </div>
            <div className="font-bold text-slate-900">Initiate Application</div>
            <p className="text-slate-500 mt-1">
              Select clearance type (Graduation, Withdrawal, End of Year) and broadcast electronic clearance request.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
              2
            </div>
            <div className="font-bold text-slate-900">Department Audits</div>
            <p className="text-slate-500 mt-1">
              Library, dorms, cafeteria, and academic labs review property and record any missing items or fines.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-xs mb-2">
              3
            </div>
            <div className="font-bold text-slate-900">Resolve Liabilities</div>
            <p className="text-slate-500 mt-1">
              Settle overdue fines via Telebirr / CBE Birr, return borrowed keys or books, and obtain digital signatures.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
            <div className="w-6 h-6 rounded-full bg-emerald-700 text-white flex items-center justify-center font-bold text-xs mb-2">
              4
            </div>
            <div className="font-bold text-slate-900">Registrar Sign-off</div>
            <p className="text-slate-500 mt-1">
              University Registrar issues certified clearance certificate with QR code for gate pass and degree release.
            </p>
          </div>
        </div>
      </div>

      {/* Directory of 9 Offices */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <h3 className="text-sm font-bold text-slate-900 mb-1">Required Department Clearances & Checkpoints</h3>
        <p className="text-xs text-slate-500 mb-4">
          Every graduating student must secure digital endorsements from all 9 directorates.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
          {Object.values(DEPARTMENTS_METADATA).map((meta, index) => (
            <div key={meta.key} className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="font-bold text-slate-900">{meta.name}</span>
                <span className="text-[10px] font-mono text-slate-400">Office {index + 1}</span>
              </div>
              <div className="text-[11px] text-slate-500 font-medium">{meta.subtitle}</div>
              <p className="text-slate-600 text-[11px] leading-relaxed">{meta.description}</p>
              <div className="pt-1.5 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                <span>Director: {meta.leadOfficer}</span>
                <span className="font-mono">{meta.building.split(',')[0]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Specialized Clearance Guides */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Vacation & Campus Exit Guide */}
        <div className="bg-emerald-950 text-white rounded-xl p-5 shadow-xs border border-emerald-900">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-400 text-emerald-950 tracking-wider mb-2">
            Boqonnaaf Gibiidhaa Ba'uu
          </div>
          <h3 className="text-base font-bold text-white mb-2">
            Vacation Campus Departure & Luggage Clearance
          </h3>
          <p className="text-xs text-emerald-100 leading-relaxed mb-3">
            Students leaving campus for semester break or holidays must obtain a Vacation Exit Pass before proceeding through the main security gate:
          </p>
          <ul className="text-xs text-emerald-200 space-y-2 list-disc list-inside">
            <li>
              <strong>Dormitory Room Key Handover:</strong> Surrender room keys to your block proctor to lock the dorm room inventory.
            </li>
            <li>
              <strong>Library Book Return:</strong> Settle or return all borrowed library textbooks before traveling.
            </li>
            <li>
              <strong>Meal Barcode Suspension:</strong> Cafeteria dining privileges are paused for the duration of the vacation.
            </li>
            <li>
              <strong>Main Gate Security Inspection:</strong> Present your digital or printed Vacation Gate Pass at the main gate for luggage verification.
            </li>
          </ul>
        </div>

        {/* Lost Student ID Card Guide */}
        <div className="bg-slate-900 text-white rounded-xl p-5 shadow-xs border border-amber-900/50">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-amber-400 text-slate-950 tracking-wider mb-2">
            Clearance Yeroo ID Card Gatan
          </div>
          <h3 className="text-base font-bold text-white mb-2">
            Lost Student ID Replacement Multi-Sector Procedure
          </h3>
          <p className="text-xs text-slate-300 leading-relaxed mb-3">
            To prevent identity theft, unauthorized dining, and book borrowing fraud, replacing a lost ID requires a 6-sector audit:
          </p>
          <ol className="text-xs text-slate-300 space-y-1.5 list-decimal list-inside">
            <li>
              <strong>Campus Police:</strong> File an incident report to obtain an official police lost card tracking number.
            </li>
            <li>
              <strong>Library Circulation:</strong> Audit circulation records to verify no fraudulent books were taken.
            </li>
            <li>
              <strong>Dining Hall:</strong> Deactivate and blacklist the old ID card barcode to prevent food theft.
            </li>
            <li>
              <strong>Block Proctor:</strong> Confirm student identity and active dormitory residence.
            </li>
            <li>
              <strong>Finance Directorate:</strong> Settle 150 ETB card replacement fee via Telebirr / CBE Birr.
            </li>
            <li>
              <strong>Office of the Registrar:</strong> Authorize, encode, and print the new replacement student ID card.
            </li>
          </ol>
        </div>
      </div>

      {/* FAQs & Campus Help */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center gap-2 mb-3">
          <HelpCircle className="w-4 h-4 text-slate-700" />
          <h3 className="text-sm font-bold text-slate-900">Frequently Asked Questions</h3>
        </div>

        <div className="space-y-3 text-xs">
          <div className="p-3 bg-slate-50 rounded-lg">
            <h4 className="font-bold text-slate-900">How do I settle library or dormitory fines online?</h4>
            <p className="text-slate-600 mt-1">
              In your Student Tracker, any active liability provides a "Settle Hold" button. You can pay via Telebirr or CBE Birr and input the transaction reference, or visit the department circulation desk for instant reconciliation.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg">
            <h4 className="font-bold text-slate-900">Is the printable digital certificate legally accepted?</h4>
            <p className="text-slate-600 mt-1">
              Yes. The generated certificate features the official Danbi Dollo University seal, registrar director signature code, and a tamper-proof cryptographic QR token verifiable by employers and campus gate security.
            </p>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg">
            <h4 className="font-bold text-slate-900">What is the Cost Sharing Directorate requirement?</h4>
            <p className="text-slate-600 mt-1">
              Under Ethiopian Higher Education proclamation, graduating students must sign and record their Higher Education Cost Sharing bond (#CS-DaDU) with the finance office before official degree parchment and transcript dispatch.
            </p>
          </div>
        </div>
      </div>

      {/* Localhost & XAMPP Setup Guide (Qajeelfama App kana Localhost & XAMPP irratti Banuu) */}
      <div className="bg-gradient-to-br from-slate-900 to-emerald-950 border border-emerald-800/40 rounded-xl p-5 text-white shadow-md">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 font-mono text-sm font-bold">
              &gt;_
            </div>
            <div>
              <h3 className="text-sm font-bold text-emerald-200">
                Akkaataa App kana Localhost fi XAMPP irratti Run Gochuu (Step-by-Step)
              </h3>
              <p className="text-[11px] text-slate-300">
                Karaan salphaan XAMPP (Apache) fi Node.js fayyadamuun kompitara keessan irratti hojjachiisuu
              </p>
            </div>
          </div>
          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded font-medium">
            Local Development Guide
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          {/* Option 1: XAMPP Apache Method */}
          <div className="bg-slate-900/80 border border-slate-700/60 rounded-lg p-4 space-y-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-[10px] border border-amber-500/40">
                  MALA 1 (XAMPP APACHE)
                </span>
                <span className="font-semibold text-slate-200 text-xs">XAMPP htdocs Fayyadamuun</span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed mb-3">
                Faayila qophaa'aa (Production Build) battalatti buufattanii folder <code className="text-amber-300 bg-slate-950 px-1 py-0.5 rounded">htdocs</code> keessa kaa'uuf:
              </p>
              <div className="space-y-2 text-[11px]">
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">1.</span>
                  <span>Button asii gadii tuquun <strong>Package (.ZIP)</strong> buufadhaa.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">2.</span>
                  <span>Faayila bu'e zip baasaatii (Extract), folder: <br/><code className="text-amber-300 bg-slate-950 px-1.5 py-0.5 rounded block mt-1 font-mono">C:\xampp\htdocs\dadu-clearance\</code> keessa kaa'aa.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">3.</span>
                  <span>XAMPP Control Panel banaa &gt; <strong>Apache "Start"</strong> godhaa.</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="font-bold text-emerald-400">4.</span>
                  <span>Browser keessan irratti: <code className="text-emerald-300 bg-slate-950 px-1.5 py-0.5 rounded block mt-1 font-mono">http://localhost/dadu-clearance/</code> banaa!</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <button
                onClick={handleDownloadZip}
                disabled={downloading}
                className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-bold text-xs transition-colors cursor-pointer shadow-sm disabled:opacity-50"
              >
                {downloading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>{downloadStatus || 'Qopheessaa jira...'}</span>
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    <span>Faayila XAMPP Buufadhu (.ZIP Download)</span>
                  </>
                )}
              </button>
              {downloadStatus && !downloading && (
                <p className="text-[10px] text-emerald-300 mt-1 text-center font-medium">
                  {downloadStatus}
                </p>
              )}
            </div>
          </div>

          {/* Option 2: Node.js Dev Server (Direct & Fastest) */}
          <div className="bg-slate-900/80 border border-slate-700/60 rounded-lg p-4 space-y-3">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 font-bold text-[10px] border border-blue-500/40">
                MALA 2 (NODE.JS DEV)
              </span>
              <span className="font-semibold text-slate-200 text-xs">Direct Node / Vite Server (Salphaa)</span>
            </div>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              React + Vite kallattiin Node.js irratti dafee banamuuf (hot-reload waliin):
            </p>
            <div className="space-y-2 text-[11px]">
              <div className="flex items-start gap-2">
                <span className="font-bold text-blue-400">1.</span>
                <span>Node.js kompitara kee irratti yoo hin jiraanne nodejs.org irraa buusi.</span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-blue-400">2.</span>
                <span>Folder app kana keessatti CMD baniitii: <code className="text-blue-300 bg-slate-950 px-1.5 py-0.5 rounded block mt-1">npm install</code></span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-blue-400">3.</span>
                <span>Server jalqabsiisuuf: <code className="text-blue-300 bg-slate-950 px-1.5 py-0.5 rounded block mt-1">npm run dev</code></span>
              </div>
              <div className="flex items-start gap-2">
                <span className="font-bold text-blue-400">4.</span>
                <span>Browser kee banee: <code className="text-emerald-300 bg-slate-950 px-1.5 py-0.5 rounded block mt-1 font-mono">http://localhost:3000</code> banee hojjedhu!</span>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between flex-wrap gap-2">
          <span>Hubachiisa: XAMPP Apache port 80 irratti yoo conflict qabaate, XAMPP config irraa port 8080 geeddaruu dandeessu.</span>
          <span className="text-emerald-400 font-mono">Danbi Dollo University IT Directorate</span>
        </div>
      </div>

      {/* Programming Languages & Technologies Used Section */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex items-center gap-2 mb-4">
          <Code2 className="w-5 h-5 text-indigo-600" />
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Gosa Afaan Saganteessuu fi Teeknooloojiiwwan Fayyadaman (Technologies Used)
            </h3>
            <p className="text-xs text-slate-500">
              Appilikeeshinii DaDU Digital University Clearance kana ijaaruuf kanneen hojiirra oolan:
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">TypeScript</span>
              <span className="px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-mono text-[10px] font-bold">Programming Lang</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Koodiin appii kanaa guutummaatti TypeScript dhaan barreeffame. Dogoggora koodii ittisuu, data types fi interfaces qindeesseera.
            </p>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">React 19</span>
              <span className="px-1.5 py-0.5 rounded bg-cyan-100 text-cyan-700 font-mono text-[10px] font-bold">UI Framework</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Component-based architecture, dynamic real-time status updates, context state management fi reactive UI uumuuf tajaajile.
            </p>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">Tailwind CSS v4</span>
              <span className="px-1.5 py-0.5 rounded bg-teal-100 text-teal-700 font-mono text-[10px] font-bold">Styling Engine</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Bifa bareedaa, responsive mobile/desktop layout, ID cards, stamp fi certificate bifa official ta'een diizaayinii gochuuf.
            </p>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">HTML5 Canvas & QR</span>
              <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-mono text-[10px] font-bold">Verification Tech</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Asxaa Yuunvarsiitii, QR code sobaa hin taane (tamper-proof) fi Code-128 barcode ID card irratti battalatti uumuuf.
            </p>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">Vite Build Tool</span>
              <span className="px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 font-mono text-[10px] font-bold">Bundler & Dev</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              Saffisaan compile godhee koodii xixinneessuun (minifying) faayila production dist folder keessatti XAMPP htdocs fi servers biroof qopheessa.
            </p>
          </div>

          <div className="p-3 rounded-lg border border-slate-200 bg-slate-50/70 hover:border-indigo-300 transition-colors">
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-slate-900">Apache (.htaccess)</span>
              <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-700 font-mono text-[10px] font-bold">Server Config</span>
            </div>
            <p className="text-slate-600 text-[11px] leading-relaxed">
              XAMPP Apache server irratti Single Page Application (SPA) akka dogoggora 404 malee birmaduun hojjetu qindeesseera.
            </p>
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <div className="text-center text-xs text-slate-400 py-3">
        Danbi Dollo University · Dembi Dolo, Oromia, Ethiopia · Web: www.dadu.edu.et · Registrar Contact: registrar@dadu.edu.et
      </div>
    </div>
  );
};
