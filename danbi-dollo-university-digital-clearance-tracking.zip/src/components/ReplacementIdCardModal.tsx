import React, { useState } from 'react';
import { ClearanceRequest } from '../types/clearance';
import { DADU_EMBLEM_URL } from '../data/mockData';
import { useClearance } from '../context/ClearanceContext';
import {
  AlertCircle,
  Building,
  CheckCircle2,
  Clock,
  CreditCard,
  Download,
  FileText,
  IdCard,
  Printer,
  QrCode,
  Shield,
  ShieldAlert,
  ShieldCheck,
  User,
  X,
} from 'lucide-react';

interface Props {
  request: ClearanceRequest;
  onClose: () => void;
}

export const ReplacementIdCardModal: React.FC<Props> = ({ request, onClose }) => {
  const { issueReplacementId, payLostIdReplacementFee } = useClearance();
  const [activeTab, setActiveTab] = useState<'id_card' | 'audit_slip'>('id_card');

  const student = request.student;
  const lostId = request.lostIdIncident || {
    policeReportNo: 'DaDU-POL-2026-8812',
    incidentDate: '2026-10-24',
    incidentLocation: 'Main Campus Dining Plaza',
    replacementFeeETB: 150,
    replacementFeePaid: false,
    replacementIdIssued: false,
  };

  const isFeePaid = lostId.replacementFeePaid || request.departments.cost_sharing?.status === 'CLEARED';
  const isPoliceCleared = request.departments.campus_police?.status === 'CLEARED';
  const isLibraryCleared = request.departments.library?.status === 'CLEARED';
  const isCafeteriaCleared = request.departments.cafeteria?.status === 'CLEARED';
  const isDormCleared = request.departments.dormitory?.status === 'CLEARED';
  const isAllSectorsCleared = isFeePaid && isPoliceCleared && isLibraryCleared && isCafeteriaCleared && isDormCleared;
  const isIdIssued = lostId.replacementIdIssued || request.finalCertificateIssued;

  const handlePrint = () => {
    window.print();
  };

  const handlePayFee = () => {
    payLostIdReplacementFee(request.id, 'Telebirr');
  };

  const handleIssueCard = () => {
    issueReplacementId(request.id);
  };

  const newBarcode = lostId.newStudentIdBarcode || 'DADU-ID-2026-90412';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Top Control Bar */}
        <div className="no-print flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-3">
            <IdCard className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-semibold tracking-wide">
                Lost Student ID Multi-Sector Clearance & Replacement Card
              </h3>
              <p className="text-xs text-slate-400">
                Danbi Dollo University · Office of the Registrar
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex bg-slate-800 p-0.5 rounded-lg text-xs">
              <button
                onClick={() => setActiveTab('id_card')}
                className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'id_card'
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Replacement ID Card
              </button>
              <button
                onClick={() => setActiveTab('audit_slip')}
                className={`px-3 py-1 rounded-md transition-colors cursor-pointer ${
                  activeTab === 'audit_slip'
                    ? 'bg-amber-400 text-slate-950 font-bold'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                Sector Clearance Slip
              </button>
            </div>
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Status Callout if Action Required */}
        {!isIdIssued && (
          <div className="no-print bg-amber-50 border-b border-amber-200 px-6 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-amber-900">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
              <span>
                {!isFeePaid
                  ? 'Finance hold pending: 150 ETB card replacement fee must be paid before card issuance.'
                  : !isAllSectorsCleared
                  ? 'Sector clearance in progress. Waiting for all sector officers to sign off.'
                  : 'All sectors cleared! The Registrar is ready to issue and print the replacement ID card.'}
              </span>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              {!isFeePaid && (
                <button
                  onClick={handlePayFee}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  Pay 150 ETB via Telebirr
                </button>
              )}
              {isFeePaid && !isIdIssued && (
                <button
                  onClick={handleIssueCard}
                  className="px-3 py-1 bg-emerald-700 hover:bg-emerald-800 text-white rounded font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Issue Replacement Card
                </button>
              )}
            </div>
          </div>
        )}

        {/* Content Area */}
        <div id="printable-certificate" className="p-6 sm:p-10 bg-slate-50">
          {activeTab === 'id_card' ? (
            <div className="space-y-8 max-w-2xl mx-auto">
              <div className="text-center">
                <span className="inline-block px-3 py-1 bg-emerald-100 text-emerald-900 rounded-full text-xs font-bold uppercase tracking-wider mb-2">
                  Official Replacement Identification Card
                </span>
                <h2 className="text-xl font-black text-slate-900">
                  Danbi Dollo University · Replacement Student ID
                </h2>
                <p className="text-xs text-slate-500">
                  Issued following comprehensive 6-sector university clearance
                </p>
              </div>

              {/* ID CARD FRONT */}
              <div className="w-full max-w-md mx-auto aspect-[1.586/1] bg-white rounded-2xl shadow-xl border-2 border-emerald-800 overflow-hidden relative flex flex-col justify-between">
                {/* ID Card Top Banner */}
                <div className="bg-gradient-to-r from-emerald-950 via-emerald-800 to-emerald-900 text-white px-4 py-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <img
                      src={DADU_EMBLEM_URL}
                      alt="DaDU Logo"
                      className="w-10 h-10 object-contain rounded-full bg-white p-0.5"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <div className="text-[10px] font-semibold text-emerald-200 tracking-wider uppercase">
                        Federal Democratic Republic of Ethiopia
                      </div>
                      <div className="text-xs font-black tracking-wide text-white">
                        DANBI DOLLO UNIVERSITY
                      </div>
                      <div className="text-[9px] text-emerald-100 font-medium">
                        STUDENT IDENTITY CARD
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-extrabold uppercase bg-red-600 text-white px-2 py-0.5 rounded shadow-xs tracking-wider">
                      REPLACEMENT
                    </span>
                  </div>
                </div>

                {/* ID Card Body */}
                <div className="p-4 flex-1 flex gap-4 items-center">
                  {/* Photo & Barcode Left */}
                  <div className="flex flex-col items-center shrink-0">
                    <img
                      src={student.avatarUrl}
                      alt={student.fullName}
                      className="w-20 h-24 object-cover rounded-md border-2 border-slate-300 shadow-xs"
                      referrerPolicy="no-referrer"
                    />
                    <span className="text-[9px] font-mono text-slate-600 mt-1 font-semibold">
                      BATCH {student.admissionYear}
                    </span>
                  </div>

                  {/* Student Details Right */}
                  <div className="flex-1 space-y-1 text-slate-900 min-w-0">
                    <div>
                      <div className="text-[9px] text-slate-500 uppercase font-semibold">
                        Full Name
                      </div>
                      <div className="text-sm font-bold truncate text-slate-950 leading-tight">
                        {student.fullName}
                      </div>
                    </div>

                    <div>
                      <div className="text-[9px] text-slate-500 uppercase font-semibold">
                        Student ID No
                      </div>
                      <div className="text-xs font-mono font-black text-emerald-900 tracking-wider">
                        {student.studentId}
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[10px]">
                      <div>
                        <div className="text-[8px] text-slate-500 uppercase font-semibold">
                          Department
                        </div>
                        <div className="font-semibold truncate text-slate-800">
                          {student.department}
                        </div>
                      </div>
                      <div>
                        <div className="text-[8px] text-slate-500 uppercase font-semibold">
                          Program
                        </div>
                        <div className="font-semibold text-slate-800">
                          {student.program}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-1 text-[10px] pt-1">
                      <div>
                        <div className="text-[8px] text-slate-500 uppercase font-semibold">
                          Issue Date
                        </div>
                        <div className="font-mono text-slate-800">
                          {request.certificateIssueDate
                            ? new Date(request.certificateIssueDate).toLocaleDateString()
                            : new Date().toLocaleDateString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-[8px] text-slate-500 uppercase font-semibold">
                          Valid Until
                        </div>
                        <div className="font-mono text-slate-800">July 2027</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* ID Card Footer with Barcode & Seal */}
                <div className="bg-slate-100 border-t border-slate-200 px-4 py-2 flex items-center justify-between">
                  <div className="space-y-0.5">
                    {/* Simulated Code-128 Barcode */}
                    <div className="flex items-center gap-[2px] h-5">
                      {Array.from({ length: 38 }).map((_, i) => (
                        <div
                          key={i}
                          className={`h-full bg-slate-900 ${
                            i % 4 === 0 ? 'w-1' : i % 3 === 0 ? 'w-[2px]' : 'w-[1px]'
                          }`}
                        />
                      ))}
                    </div>
                    <div className="font-mono text-[9px] text-slate-600 tracking-widest font-bold">
                      *{newBarcode}*
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[8px] font-bold text-slate-500 uppercase">
                      Registrar Authorized
                    </div>
                    <div className="font-serif italic font-bold text-[11px] text-emerald-950">
                      Dr. Dereje Feyissa
                    </div>
                  </div>
                </div>
              </div>

              {/* ID CARD BACK */}
              <div className="w-full max-w-md mx-auto aspect-[1.586/1] bg-white rounded-2xl shadow-xl border-2 border-slate-300 overflow-hidden relative flex flex-col justify-between p-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1.5">
                    <span className="text-[10px] font-bold uppercase text-slate-700">
                      Important Terms & Conditions
                    </span>
                    <span className="text-[9px] font-mono text-slate-500">
                      Serial: {newBarcode}
                    </span>
                  </div>
                  <ul className="text-[9px] text-slate-600 space-y-1 list-disc list-inside leading-tight">
                    <li>This card is the property of Danbi Dollo University.</li>
                    <li>Surrender to university authorities upon request or termination of study.</li>
                    <li>If found, please return to DaDU Registrar Office or call +251 57 555 2211.</li>
                    <li>Non-transferable. De-registered cards will be confiscated by Campus Security.</li>
                  </ul>
                </div>

                <div className="grid grid-cols-2 gap-4 border-t border-slate-200 pt-3 text-[10px]">
                  <div>
                    <div className="text-[8px] text-slate-500 uppercase font-semibold">
                      Emergency Contact
                    </div>
                    <div className="font-mono text-slate-800">{student.phone}</div>
                    <div className="text-slate-600">Dembi Dolo, Oromia, Ethiopia</div>
                  </div>
                  <div className="flex flex-col items-end justify-center">
                    <div className="border border-slate-400 border-dashed rounded px-3 py-1 text-center">
                      <div className="text-[8px] text-slate-500 uppercase">Student Sign</div>
                      <div className="font-serif italic text-xs font-bold text-slate-800">
                        {student.fullName.split(' ')[0]}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* SECTOR CLEARANCE SLIP VIEW */
            <div className="border-2 border-slate-300 bg-white p-6 rounded-lg space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-4">
                <div className="flex items-center gap-3">
                  <img
                    src={DADU_EMBLEM_URL}
                    alt="Logo"
                    className="w-12 h-12 object-contain"
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      Danbi Dollo University · Lost Student ID Multi-Sector Clearance Slip
                    </h3>
                    <p className="text-xs text-slate-500">
                      Office of the Registrar · Incident Tracking & ID Replacement Form
                    </p>
                  </div>
                </div>
                <div className="text-right text-xs">
                  <div className="font-semibold text-slate-700">Police Incident Report:</div>
                  <div className="font-mono font-bold text-amber-700">{lostId.policeReportNo}</div>
                </div>
              </div>

              {/* Student Summary */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-3 bg-slate-50 rounded border border-slate-200 text-xs">
                <div>
                  <span className="text-slate-500 block">Student Name:</span>
                  <span className="font-bold text-slate-900">{student.fullName}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Student ID:</span>
                  <span className="font-mono font-bold text-slate-900">{student.studentId}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Department:</span>
                  <span className="font-semibold text-slate-900">{student.department}</span>
                </div>
                <div>
                  <span className="text-slate-500 block">Replacement Fee:</span>
                  <span className="font-bold text-emerald-800">150 ETB ({isFeePaid ? 'PAID' : 'UNPAID'})</span>
                </div>
              </div>

              {/* 6-Sector Audit Checklist */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 mb-3">
                  Mandatory Multi-Sector Verification Checklist
                </h4>
                <div className="divide-y divide-slate-200 border border-slate-200 rounded-md overflow-hidden text-xs">
                  {/* 1. Campus Police */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">1. Campus Police & Security</div>
                      <div className="text-slate-500 text-[11px]">
                        Incident investigation & loss report verified. Report #{lostId.policeReportNo}
                      </div>
                    </div>
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold bg-emerald-100 text-emerald-800">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      CLEARED
                    </span>
                  </div>

                  {/* 2. Library */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">2. University Library Directorate</div>
                      <div className="text-slate-500 text-[11px]">
                        Circulation audit: Zero books or journal loans outstanding under lost ID.
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        isLibraryCleared ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isLibraryCleared ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {isLibraryCleared ? 'CLEARED' : 'PENDING'}
                    </span>
                  </div>

                  {/* 3. Cafeteria */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">3. Dining Hall / Cafeteria Service</div>
                      <div className="text-slate-500 text-[11px]">
                        Deactivated and blacklisted lost ID barcode to prevent unauthorized meal dining.
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        isCafeteriaCleared ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isCafeteriaCleared ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {isCafeteriaCleared ? 'BLOCKED & CLEARED' : 'PENDING'}
                    </span>
                  </div>

                  {/* 4. Dormitory Proctor */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">4. Dormitory & Proctoring Office</div>
                      <div className="text-slate-500 text-[11px]">
                        In-person physical identification confirmed for {student.dormBlock || 'Dorm Block'}, {student.dormRoom || 'Room'}.
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        isDormCleared ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isDormCleared ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {isDormCleared ? 'CLEARED' : 'PENDING'}
                    </span>
                  </div>

                  {/* 5. Finance Directorate */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">5. Finance & Cost Sharing Directorate</div>
                      <div className="text-slate-500 text-[11px]">
                        150 ETB card replacement administrative charge reconciliation.
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        isFeePaid ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isFeePaid ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {isFeePaid ? 'PAID & CLEARED' : 'UNPAID (150 ETB)'}
                    </span>
                  </div>

                  {/* 6. Registrar */}
                  <div className="p-3 bg-white flex items-center justify-between">
                    <div>
                      <div className="font-bold text-slate-900">6. University Registrar Office</div>
                      <div className="text-slate-500 text-[11px]">
                        Printing & releasing new official replacement student ID card with new security barcode.
                      </div>
                    </div>
                    <span
                      className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-xs font-bold ${
                        isIdIssued ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {isIdIssued ? (
                        <CheckCircle2 className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {isIdIssued ? 'NEW CARD ISSUED' : 'AWAITING FINAL RELEASE'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Actions Footer */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-200">
                <div className="text-xs text-slate-500">
                  Audit serial: <span className="font-mono">{request.qrValidationToken}</span>
                </div>
                <div className="flex items-center gap-3">
                  {!isFeePaid && (
                    <button
                      onClick={handlePayFee}
                      className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-xs font-bold transition-colors cursor-pointer"
                    >
                      Settle 150 ETB Fee Now
                    </button>
                  )}
                  {isFeePaid && !isIdIssued && (
                    <button
                      onClick={handleIssueCard}
                      className="px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-md text-xs font-bold transition-colors cursor-pointer"
                    >
                      Print & Issue Replacement ID
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
