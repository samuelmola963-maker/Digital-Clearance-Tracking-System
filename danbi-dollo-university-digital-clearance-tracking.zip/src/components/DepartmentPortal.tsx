import React, { useState } from 'react';
import { useClearance } from '../context/ClearanceContext';
import { DepartmentKey, HoldCategory } from '../types/clearance';
import { DEPARTMENTS_METADATA } from '../data/mockData';
import {
  AlertCircle,
  Building,
  CheckCheck,
  CheckCircle2,
  Clock,
  Filter,
  Layers,
  MapPin,
  PlusCircle,
  Search,
  ShieldAlert,
  UserCheck,
} from 'lucide-react';

export const DepartmentPortal: React.FC = () => {
  const {
    requests,
    activeDepartment,
    setActiveDepartment,
    approveDepartment,
    placeHold,
    batchApproveDepartment,
  } = useClearance();

  const currentMeta = DEPARTMENTS_METADATA[activeDepartment];

  // Filtering & search
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'CLEARED' | 'HOLD'>('ALL');

  // Modal for placing a hold
  const [isHoldModalOpen, setIsHoldModalOpen] = useState(false);
  const [targetRequestId, setTargetRequestId] = useState<string | null>(null);
  const [holdItem, setHoldItem] = useState('');
  const [holdCategory, setHoldCategory] = useState<HoldCategory>('PROPERTY');
  const [holdAmountETB, setHoldAmountETB] = useState<string>('');
  const [holdInstructions, setHoldInstructions] = useState('');

  // Modal for approving
  const [isApproveModalOpen, setIsApproveModalOpen] = useState(false);
  const [approveRequestId, setApproveRequestId] = useState<string | null>(null);
  const [approvalNotes, setApprovalNotes] = useState('');

  // Filter requests for the active department
  const departmentRecords = requests.map((req) => {
    const deptApproval = req.departments[activeDepartment];
    return {
      request: req,
      student: req.student,
      deptApproval,
    };
  });

  const filteredRecords = departmentRecords.filter(({ student, deptApproval }) => {
    const matchesSearch =
      student.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.studentId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.department.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;
    if (statusFilter === 'ALL') return true;
    return deptApproval?.status === statusFilter;
  });

  const pendingCount = departmentRecords.filter((r) => r.deptApproval?.status === 'PENDING').length;
  const holdCount = departmentRecords.filter((r) => r.deptApproval?.status === 'HOLD').length;
  const clearedCount = departmentRecords.filter((r) => r.deptApproval?.status === 'CLEARED').length;

  const handlePlaceHoldSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetRequestId) return;
    placeHold(targetRequestId, activeDepartment, {
      item: holdItem,
      category: holdCategory,
      amountETB: holdAmountETB ? parseFloat(holdAmountETB) : undefined,
      instructions:
        holdInstructions || 'Please report to the office desk to settle this liability before clearance.',
    });
    setIsHoldModalOpen(false);
    setTargetRequestId(null);
    setHoldItem('');
    setHoldAmountETB('');
    setHoldInstructions('');
  };

  const handleApproveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!approveRequestId) return;
    approveDepartment(
      approveRequestId,
      activeDepartment,
      approvalNotes || 'Conditions inspected and cleared by department officer.'
    );
    setIsApproveModalOpen(false);
    setApproveRequestId(null);
    setApprovalNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Department Tabs Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-2 shadow-xs">
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {(Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).map((key) => {
            const meta = DEPARTMENTS_METADATA[key];
            const isActive = activeDepartment === key;
            const deptPending = requests.filter((r) => r.departments[key]?.status === 'PENDING').length;

            return (
              <button
                key={key}
                onClick={() => setActiveDepartment(key)}
                className={`flex items-center gap-2 px-3 py-2 text-xs font-semibold rounded-lg whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <span>{meta.name.split(' ')[0]}</span>
                {deptPending > 0 ? (
                  <span
                    className={`font-mono text-[10px] px-1.5 py-0.2 rounded-full ${
                      isActive ? 'bg-amber-400 text-slate-950 font-bold' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {deptPending}
                  </span>
                ) : null}
              </button>
            );
          })}
        </div>
      </div>

      {/* Office Header Card */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Administrative Desk
              </span>
              <span className="text-xs text-slate-400">·</span>
              <span className="text-xs font-semibold text-slate-700">{currentMeta.subtitle}</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 mt-0.5">{currentMeta.name}</h2>
            <div className="flex items-center gap-3 text-xs text-slate-600 mt-1 flex-wrap">
              <span className="flex items-center gap-1">
                <UserCheck className="w-3.5 h-3.5 text-slate-400" />
                <strong>{currentMeta.leadOfficer}</strong> ({currentMeta.title})
              </span>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-1 text-slate-500">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {currentMeta.building}
              </span>
              <span aria-hidden="true">·</span>
              <span className="font-mono text-[11px] text-slate-500">Stamp: {currentMeta.stampCode}</span>
            </div>
          </div>

          {/* Quick Metrics & Batch Clear */}
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-lg text-xs">
              <span className="text-slate-500">Pending:</span>
              <span className="font-mono font-bold text-slate-900">{pendingCount}</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-500">Holds:</span>
              <span className="font-mono font-bold text-rose-600">{holdCount}</span>
              <span className="text-slate-300">|</span>
              <span className="text-slate-500">Cleared:</span>
              <span className="font-mono font-bold text-emerald-600">{clearedCount}</span>
            </div>

            <button
              onClick={() => batchApproveDepartment(activeDepartment)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5 text-amber-400" />
              Batch Clear Free Students
            </button>
          </div>
        </div>
      </div>

      {/* Student Registry Table & Filters */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-xs">
        {/* Table Controls */}
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-slate-50/50">
          <div className="relative flex-1 max-w-sm">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by student ID, name, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-200 rounded-lg focus:outline-hidden focus:border-slate-900"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs text-slate-500 hidden sm:inline">Filter:</span>
            {(['ALL', 'PENDING', 'HOLD', 'CLEARED'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setStatusFilter(filter)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                  statusFilter === filter
                    ? 'bg-slate-900 text-white'
                    : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                {filter === 'ALL' ? 'All Rows' : filter}
              </button>
            ))}
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-100/75 text-slate-600 font-semibold uppercase tracking-wider text-[10px] border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Student Name & ID</th>
                <th className="px-4 py-3">Academic Dept & Program</th>
                <th className="px-4 py-3">Clearance Type</th>
                <th className="px-4 py-3">Desk Status</th>
                <th className="px-4 py-3">Liabilities / Holds</th>
                <th className="px-4 py-3 text-right">Desk Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRecords.length > 0 ? (
                filteredRecords.map(({ request, student, deptApproval }) => {
                  const isCleared = deptApproval?.status === 'CLEARED';
                  const isHold = deptApproval?.status === 'HOLD';
                  const isPending = !isCleared && !isHold;

                  return (
                    <tr key={request.id} className="hover:bg-slate-50/75 transition-colors">
                      <td className="px-4 py-3.5">
                        <div className="flex items-center gap-3">
                          <img
                            src={student.avatarUrl}
                            alt={student.fullName}
                            className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          <div>
                            <div className="font-bold text-slate-900">{student.fullName}</div>
                            <div className="font-mono text-slate-500 text-[11px]">{student.studentId}</div>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-800">{student.department}</div>
                        <div className="text-[11px] text-slate-500">{student.program} Program</div>
                      </td>

                      <td className="px-4 py-3.5">
                        <span className={`inline-flex items-center gap-1 font-semibold text-xs px-2 py-0.5 rounded ${
                          request.clearanceType === 'VACATION_EXIT'
                            ? 'bg-emerald-100 text-emerald-900'
                            : request.clearanceType === 'LOST_ID_REPLACEMENT'
                            ? 'bg-amber-100 text-amber-900'
                            : 'bg-slate-100 text-slate-800'
                        }`}>
                          {request.clearanceType === 'VACATION_EXIT'
                            ? '🧳 Vacation Exit'
                            : request.clearanceType === 'LOST_ID_REPLACEMENT'
                            ? '💳 Lost ID Replacement'
                            : '🎓 Graduation'}
                        </span>
                        <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                          {request.academicYear} Sem {request.semester}
                        </div>
                      </td>

                      <td className="px-4 py-3.5">
                        {isCleared ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Cleared
                          </span>
                        ) : isHold ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-rose-50 text-rose-800 border border-rose-200">
                            <AlertCircle className="w-3 h-3 text-rose-600" />
                            Hold Active
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold bg-amber-50 text-amber-800 border border-amber-200">
                            <Clock className="w-3 h-3 text-amber-600" />
                            Pending Review
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5">
                        {deptApproval?.holds && deptApproval.holds.length > 0 ? (
                          <div className="space-y-1">
                            {deptApproval.holds.map((h) => (
                              <div
                                key={h.id}
                                className={`text-[11px] ${
                                  h.resolved ? 'text-slate-400 line-through' : 'text-rose-700 font-medium'
                                }`}
                              >
                                • {h.item} {h.amountETB ? `(${h.amountETB} ETB)` : ''}
                                {h.resolved && ' [Settled]'}
                              </div>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px] italic">Zero liabilities recorded</span>
                        )}
                      </td>

                      <td className="px-4 py-3.5 text-right whitespace-nowrap">
                        <div className="flex items-center justify-end gap-2">
                          {!isCleared && (
                            <button
                              onClick={() => {
                                setApproveRequestId(request.id);
                                setIsApproveModalOpen(true);
                              }}
                              className="px-2.5 py-1 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-md transition-colors cursor-pointer"
                            >
                              Approve & Stamp
                            </button>
                          )}

                          <button
                            onClick={() => {
                              setTargetRequestId(request.id);
                              setIsHoldModalOpen(true);
                            }}
                            className="px-2.5 py-1 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-md transition-colors cursor-pointer"
                          >
                            + Place Hold
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-500">
                    No student records found matching the current search and filter.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Place Hold Modal */}
      {isHoldModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-rose-400" />
                <h4 className="text-sm font-bold">Record Department Hold / Liability</h4>
              </div>
              <button
                onClick={() => setIsHoldModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handlePlaceHoldSubmit} className="p-5 space-y-4">
              <div className="p-2.5 bg-slate-50 border border-slate-200 rounded text-xs">
                <span className="font-semibold text-slate-700">Office: </span>
                <span className="font-bold text-slate-900">{currentMeta.name}</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Item Description or Violation
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Overdue Library Book: Digital Signal Processing 4th Ed."
                  value={holdItem}
                  onChange={(e) => setHoldItem(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">Liability Type</label>
                  <select
                    value={holdCategory}
                    onChange={(e) => setHoldCategory(e.target.value as HoldCategory)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                  >
                    <option value="PROPERTY">Property / Material</option>
                    <option value="FINANCIAL">Financial / Fee Fine</option>
                    <option value="ACADEMIC">Academic Obligation</option>
                    <option value="DISCIPLINARY">Disciplinary Inquiry</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Fine Amount in ETB (Optional)
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="e.g., 250"
                    value={holdAmountETB}
                    onChange={(e) => setHoldAmountETB(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Instructions for Student Resolution
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g., Return physical book to Main Circulation Desk or pay 250 ETB replacement fee."
                  value={holdInstructions}
                  onChange={(e) => setHoldInstructions(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsHoldModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 rounded-lg transition-colors cursor-pointer"
                >
                  Apply Liability Hold
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Approve Modal */}
      {isApproveModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full border border-slate-200 overflow-hidden">
            <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold">Endorse & Digitally Stamp Clearance</h4>
              </div>
              <button
                onClick={() => setIsApproveModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
            </div>

            <form onSubmit={handleApproveSubmit} className="p-5 space-y-4">
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
                <div>
                  <span className="font-semibold text-slate-600">Signing Official: </span>
                  <strong className="text-slate-900">{currentMeta.leadOfficer}</strong>
                </div>
                <div>
                  <span className="font-semibold text-slate-600">Department: </span>
                  <span className="text-slate-900">{currentMeta.name}</span>
                </div>
                <div className="font-mono text-[11px] text-slate-500">
                  Stamp Code: {currentMeta.stampCode}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Approval Endorsement Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="e.g., All lab tools and research books verified in satisfactory condition."
                  value={approvalNotes}
                  onChange={(e) => setApprovalNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900"
                />
              </div>

              <div className="text-[11px] text-slate-500">
                This will generate a verifiable cryptographic signature token on the student's institutional record.
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsApproveModalOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                >
                  Apply Digital Stamp
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
