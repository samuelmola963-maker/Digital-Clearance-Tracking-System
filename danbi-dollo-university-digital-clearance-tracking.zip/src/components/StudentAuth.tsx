import React, { useState } from 'react';
import { useClearance, validatePasswordRules } from '../context/ClearanceContext';
import { DADU_DEPARTMENTS_LIST, DADU_EMBLEM_URL } from '../data/mockData';
import {
  AlertCircle,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  KeyRound,
  Lock,
  LogOut,
  ShieldCheck,
  User,
  UserCheck,
  UserPlus,
  X,
  XCircle,
} from 'lucide-react';

interface Props {
  onSuccess?: () => void;
  onClose?: () => void;
  isModal?: boolean;
}

export const StudentAuth: React.FC<Props> = ({ onSuccess, onClose, isModal = false }) => {
  const { registerStudent, loginStudent, logout, students, currentUser } = useClearance();

  // Mode: 'QUESTION' (Ask "Do you have an account?"), 'LOGIN', or 'REGISTER'
  const [mode, setMode] = useState<'QUESTION' | 'LOGIN' | 'REGISTER'>(
    currentUser ? 'QUESTION' : 'QUESTION'
  );

  // Registration form state
  const [fullName, setFullName] = useState('');
  const [studentId, setStudentId] = useState('');
  const [department, setDepartment] = useState(DADU_DEPARTMENTS_LIST[0].name);
  const [yearOfStudy, setYearOfStudy] = useState('Graduating Class (Year 5)');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Login form state
  const [loginStudentId, setLoginStudentId] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);

  // Status feedback
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  // Password rules validation
  const passwordRules = validatePasswordRules(password);
  const passwordsMatch = password.length > 0 && password === confirmPassword;

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!fullName.trim()) {
      setErrorMessage('Please enter your full legal name.');
      return;
    }

    if (!studentId.trim()) {
      setErrorMessage('Please enter your Danbi Dollo University Student ID.');
      return;
    }

    if (!passwordRules.isValid) {
      setErrorMessage('Password must satisfy all 5 required security rules.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Passwords do not match. Please re-enter to confirm.');
      return;
    }

    const result = registerStudent({
      fullName,
      studentId,
      department,
      yearOfStudy,
      password,
    });

    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => {
        if (onSuccess) onSuccess();
        if (onClose) onClose();
      }, 700);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!loginStudentId.trim()) {
      setErrorMessage('Please enter your Student ID.');
      return;
    }

    const result = loginStudent(loginStudentId, loginPassword);
    if (result.success) {
      setSuccessMessage(result.message);
      setTimeout(() => {
        if (onSuccess) onSuccess();
        if (onClose) onClose();
      }, 600);
    } else {
      setErrorMessage(result.message);
    }
  };

  const handleQuickDemoLogin = (demoStdId: string) => {
    const std = students.find((s) => s.studentId === demoStdId);
    if (std) {
      loginStudent(std.studentId, std.password || 'Password@2026!');
      if (onSuccess) onSuccess();
      if (onClose) onClose();
    }
  };

  const handleLogout = () => {
    logout();
    setSuccessMessage('You have been logged out successfully.');
    setMode('QUESTION');
  };

  const content = (
    <div className="bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden max-w-lg w-full mx-auto">
      {/* Top Header */}
      <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={DADU_EMBLEM_URL}
            alt="Dambi Dollo University Official Logo"
            className="w-11 h-11 object-contain drop-shadow-xs"
            referrerPolicy="no-referrer"
          />
          <div>
            <h3 className="text-sm font-bold tracking-tight">Danbi Dollo University</h3>
            <p className="text-xs text-slate-400">Digital Clearance & Credential Portal</p>
          </div>
        </div>
        {isModal && onClose && (
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-md transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="p-6">
        {/* Alerts */}
        {errorMessage && (
          <div className="mb-4 p-3 bg-rose-50 border border-rose-200 rounded-lg flex items-start gap-2.5 text-xs text-rose-800">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-lg flex items-start gap-2.5 text-xs text-emerald-800">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* LOGGED IN USER OVERVIEW (If already logged in) */}
        {currentUser && mode === 'QUESTION' ? (
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Currently Logged In
                </span>
                <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  Active Session
                </span>
              </div>

              <div className="mt-3 flex items-center gap-3">
                <div className="w-11 h-11 rounded-full bg-slate-900 text-amber-400 flex items-center justify-center font-bold text-sm">
                  {currentUser.fullName.charAt(0)}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">{currentUser.fullName}</h4>
                  <div className="text-xs font-mono text-slate-500">{currentUser.studentId}</div>
                  <div className="text-xs text-slate-600 mt-0.5">
                    {currentUser.department} · {currentUser.yearOfStudy || 'Student'}
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={handleLogout}
                className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-lg transition-colors cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Log Out</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMode('REGISTER');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>Create New Account</span>
              </button>
            </div>
          </div>
        ) : mode === 'QUESTION' ? (
          /* STEP 1: ASK "DO YOU HAVE AN ACCOUNT?" */
          <div className="text-center py-2 space-y-5">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-800">
              <UserCheck className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Do you already have a clearance account?
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                Please select an option below to access your Danbi Dollo University digital clearance portal.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md mx-auto pt-2">
              {/* Option 1: Yes, Log In */}
              <button
                type="button"
                onClick={() => {
                  setMode('LOGIN');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="p-4 rounded-xl border-2 border-slate-200 hover:border-slate-900 bg-white hover:bg-slate-50 text-left transition-all cursor-pointer group shadow-xs"
              >
                <div className="w-8 h-8 rounded-lg bg-slate-100 text-slate-900 flex items-center justify-center mb-2 group-hover:bg-slate-900 group-hover:text-white transition-colors">
                  <KeyRound className="w-4 h-4" />
                </div>
                <div className="text-sm font-bold text-slate-900">Yes, Log In</div>
                <div className="text-xs text-slate-500 mt-1">
                  I already have an account and Student ID.
                </div>
              </button>

              {/* Option 2: No, Create Account */}
              <button
                type="button"
                onClick={() => {
                  setMode('REGISTER');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="p-4 rounded-xl border-2 border-amber-400 bg-amber-50/40 hover:bg-amber-50 text-left transition-all cursor-pointer group shadow-xs"
              >
                <div className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center mb-2">
                  <UserPlus className="w-4 h-4" />
                </div>
                <div className="text-sm font-bold text-slate-900">No, Create Account</div>
                <div className="text-xs text-slate-600 mt-1">
                  I am a new student registering for clearance.
                </div>
              </button>
            </div>

            {/* Quick Demo Login shortcuts */}
            <div className="pt-4 border-t border-slate-200">
              <span className="text-[11px] font-semibold text-slate-500 block mb-2">
                Or jump in instantly with a sample student profile:
              </span>
              <div className="flex flex-wrap justify-center gap-2">
                {students.slice(0, 3).map((std) => (
                  <button
                    key={std.id}
                    type="button"
                    onClick={() => handleQuickDemoLogin(std.studentId)}
                    className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md text-slate-800 transition-colors font-medium cursor-pointer"
                  >
                    {std.fullName.split(' ')[0]} ({std.department.split(' ')[0]})
                  </button>
                ))}
              </div>
            </div>
          </div>
        ) : mode === 'LOGIN' ? (
          /* STEP 2A: LOGIN FORM */
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-slate-700" />
                <h4 className="text-sm font-bold text-slate-900">Student Account Log In</h4>
              </div>
              <button
                type="button"
                onClick={() => setMode('QUESTION')}
                className="text-xs text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Back
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1">
                Student ID Number *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. DaDU/UGR/1420/14"
                value={loginStudentId}
                onChange={(e) => setLoginStudentId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono bg-white"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-800">Password *</label>
                <button
                  type="button"
                  onClick={() => setShowLoginPassword(!showLoginPassword)}
                  className="text-slate-500 hover:text-slate-800 text-[11px] inline-flex items-center gap-1 cursor-pointer"
                >
                  {showLoginPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  <span>{showLoginPassword ? 'Hide' : 'Show'}</span>
                </button>
              </div>
              <input
                type={showLoginPassword ? 'text' : 'password'}
                required
                placeholder="Enter your account password..."
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono bg-white"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              Log In to Clearance App
            </button>

            <div className="text-center pt-2">
              <span className="text-xs text-slate-500">Don't have an account yet? </span>
              <button
                type="button"
                onClick={() => {
                  setMode('REGISTER');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="text-xs font-bold text-slate-900 hover:underline cursor-pointer"
              >
                Create Account
              </button>
            </div>
          </form>
        ) : (
          /* STEP 2B: REGISTRATION FORM */
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-slate-700" />
                <h4 className="text-sm font-bold text-slate-900">Student Account Registration</h4>
              </div>
              <button
                type="button"
                onClick={() => setMode('QUESTION')}
                className="text-xs text-slate-500 hover:text-slate-900 cursor-pointer"
              >
                Back
              </button>
            </div>

            {/* 1. Full Name */}
            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1">
                Full Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Tolosa Gemechu Fufa"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 bg-white"
              />
            </div>

            {/* 2. Student ID */}
            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1">
                Student ID Number *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. DaDU/UGR/1420/14"
                value={studentId}
                onChange={(e) => setStudentId(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono bg-white"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Format: DaDU/UGR/XXXX/YY
              </span>
            </div>

            {/* 3. Department & 4. Year of Study */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1">
                  Department *
                </label>
                <select
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 bg-white"
                >
                  {DADU_DEPARTMENTS_LIST.map((d) => (
                    <option key={d.name} value={d.name}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-800 mb-1">
                  Year of Study *
                </label>
                <select
                  value={yearOfStudy}
                  onChange={(e) => setYearOfStudy(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 bg-white"
                >
                  <option value="Year 1">1st Year</option>
                  <option value="Year 2">2nd Year</option>
                  <option value="Year 3">3rd Year</option>
                  <option value="Year 4">4th Year</option>
                  <option value="Year 5">5th Year</option>
                  <option value="Graduating Class (Year 5)">Graduating Class</option>
                </select>
              </div>
            </div>

            {/* 5. Password with Explicit Security Rules */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-semibold text-slate-800">Password *</label>
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-slate-500 hover:text-slate-800 text-[11px] inline-flex items-center gap-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  <span>{showPassword ? 'Hide' : 'Show'}</span>
                </button>
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Create a strong password..."
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-hidden focus:border-slate-900 font-mono bg-white"
              />

              {/* Password Rule Checklist */}
              <div className="mt-2.5 p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] space-y-1">
                <div className="font-bold text-slate-800 mb-1 flex items-center justify-between">
                  <span>PASSWORD SECURITY RULES:</span>
                  {passwordRules.isValid ? (
                    <span className="text-emerald-700 font-semibold flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Valid
                    </span>
                  ) : (
                    <span className="text-amber-700">Must meet all criteria</span>
                  )}
                </div>

                <div
                  className={`flex items-center gap-1.5 ${
                    passwordRules.hasMinLength ? 'text-emerald-700 font-medium' : 'text-slate-500'
                  }`}
                >
                  {passwordRules.hasMinLength ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-400 inline-block shrink-0" />
                  )}
                  <span>At least 8 characters</span>
                </div>

                <div
                  className={`flex items-center gap-1.5 ${
                    passwordRules.hasUpper ? 'text-emerald-700 font-medium' : 'text-slate-500'
                  }`}
                >
                  {passwordRules.hasUpper ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-400 inline-block shrink-0" />
                  )}
                  <span>At least 1 uppercase letter (A-Z)</span>
                </div>

                <div
                  className={`flex items-center gap-1.5 ${
                    passwordRules.hasLower ? 'text-emerald-700 font-medium' : 'text-slate-500'
                  }`}
                >
                  {passwordRules.hasLower ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-400 inline-block shrink-0" />
                  )}
                  <span>At least 1 lowercase letter (a-z)</span>
                </div>

                <div
                  className={`flex items-center gap-1.5 ${
                    passwordRules.hasNumber ? 'text-emerald-700 font-medium' : 'text-slate-500'
                  }`}
                >
                  {passwordRules.hasNumber ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-400 inline-block shrink-0" />
                  )}
                  <span>At least 1 number (0-9)</span>
                </div>

                <div
                  className={`flex items-center gap-1.5 ${
                    passwordRules.hasSpecial ? 'text-emerald-700 font-medium' : 'text-slate-500'
                  }`}
                >
                  {passwordRules.hasSpecial ? (
                    <CheckCircle2 className="w-3 h-3 text-emerald-600 shrink-0" />
                  ) : (
                    <span className="w-3 h-3 rounded-full border border-slate-400 inline-block shrink-0" />
                  )}
                  <span>At least 1 special character (!@#$%^&*...)</span>
                </div>
              </div>
            </div>

            {/* 6. Confirm Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-800 mb-1">
                Confirm Password *
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                required
                placeholder="Re-enter password to confirm..."
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className={`w-full px-3 py-2 text-xs border rounded-lg focus:outline-hidden font-mono bg-white ${
                  confirmPassword.length > 0 && !passwordsMatch
                    ? 'border-rose-400 focus:border-rose-600'
                    : 'border-slate-300 focus:border-slate-900'
                }`}
              />
              {confirmPassword.length > 0 && (
                <div className="mt-1 text-[11px]">
                  {passwordsMatch ? (
                    <span className="text-emerald-700 font-medium flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Passwords match
                    </span>
                  ) : (
                    <span className="text-rose-600 font-medium flex items-center gap-1">
                      <XCircle className="w-3 h-3" /> Passwords do not match
                    </span>
                  )}
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={!passwordRules.isValid || !passwordsMatch}
              className="w-full py-2.5 px-4 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed mt-2"
            >
              Create Account & Enter App
            </button>

            <div className="text-center pt-2">
              <span className="text-xs text-slate-500">Already have an account? </span>
              <button
                type="button"
                onClick={() => {
                  setMode('LOGIN');
                  setErrorMessage('');
                  setSuccessMessage('');
                }}
                className="text-xs font-bold text-slate-900 hover:underline cursor-pointer"
              >
                Log In
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );

  if (isModal) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
        <div className="my-8 w-full max-w-lg">{content}</div>
      </div>
    );
  }

  return content;
};
