import React from 'react';
import { ClearanceRequest } from '../types/clearance';
import { DADU_EMBLEM_URL, DEPARTMENTS_METADATA } from '../data/mockData';
import { CheckCircle2, Download, Printer, ShieldCheck, X } from 'lucide-react';

interface Props {
  request: ClearanceRequest;
  onClose: () => void;
}

export const ClearanceCertificateModal: React.FC<Props> = ({ request, onClose }) => {
  const handlePrint = () => {
    window.print();
  };

  const student = request.student;
  const isCleared = request.finalCertificateIssued || request.overallStatus === 'APPROVED';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-4xl bg-white rounded-xl shadow-2xl border border-slate-200 overflow-hidden my-8">
        {/* Top Control Bar (Hidden when printing) */}
        <div className="no-print flex items-center justify-between px-6 py-4 bg-slate-900 text-white border-b border-slate-800">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-sm font-semibold tracking-wide">Official Institutional Clearance Slip</h3>
              <p className="text-xs text-slate-400">Danbi Dollo University · Registrar & Alumni Directorate</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-medium text-slate-900 bg-amber-400 hover:bg-amber-300 rounded-md transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              Print / Save PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Document Area */}
        <div id="printable-certificate" className="p-8 sm:p-12 bg-white text-slate-900">
          {/* Watermark background */}
          <div className="relative border-4 border-double border-slate-800 p-8 sm:p-10 rounded-sm">
            {/* Header Lockup */}
            <div className="flex flex-col items-center text-center pb-6 border-b-2 border-slate-900">
              <div className="flex items-center justify-center gap-6 mb-3">
                <img
                  src={DADU_EMBLEM_URL}
                  alt="Dambi Dollo University Official Logo"
                  className="w-24 h-24 object-contain"
                  referrerPolicy="no-referrer"
                />
                <div className="text-center">
                  <div className="text-xs font-semibold tracking-wider text-slate-700 uppercase">
                    Federal Democratic Republic of Ethiopia · Ministry of Education
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-950 uppercase mt-0.5">
                    DANBI DOLLO UNIVERSITY
                  </h1>
                  <div className="text-sm font-semibold text-slate-800">
                    Office of the Registrar · Student Clearance Directorate
                  </div>
                  <div className="text-xs text-slate-600 mt-1 font-mono">
                    Official Institutional Clearance & Graduation Release · Dembi Dolo, Ethiopia
                  </div>
                </div>
              </div>

              <div className="inline-block px-4 py-1 bg-slate-100 border border-slate-400 rounded-sm text-xs font-bold tracking-widest uppercase text-slate-900 mt-2">
                OFFICIAL UNIVERSITY CLEARANCE CERTIFICATE · {request.clearanceType}
              </div>
            </div>

            {/* Certificate Meta Bar */}
            <div className="flex flex-wrap items-center justify-between gap-4 py-3 border-b border-slate-300 text-xs text-slate-700">
              <div>
                <span className="font-semibold text-slate-900">Certificate Serial:</span>{' '}
                <span className="font-mono font-bold text-slate-950">
                  {request.certificateSerial || 'PENDING-REGISTRAR-APPROVAL'}
                </span>
              </div>
              <div>
                <span className="font-semibold text-slate-900">Academic Year:</span>{' '}
                <span className="font-mono">{request.academicYear} (Semester {request.semester})</span>
              </div>
              <div>
                <span className="font-semibold text-slate-900">Issue Date:</span>{' '}
                <span className="font-mono">
                  {request.certificateIssueDate
                    ? new Date(request.certificateIssueDate).toLocaleDateString('en-GB', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                      })
                    : new Date().toLocaleDateString('en-GB')}
                </span>
              </div>
            </div>

            {/* Student Identification Section */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6 py-6 border-b border-slate-300 items-center">
              <div className="flex justify-center md:justify-start">
                <img
                  src={student.avatarUrl}
                  alt={student.fullName}
                  className="w-28 h-28 object-cover rounded border-2 border-slate-800 shadow-xs"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="md:col-span-3 grid grid-cols-2 sm:grid-cols-3 gap-y-3 gap-x-4 text-xs">
                <div>
                  <div className="text-slate-500 font-medium">Student Full Name</div>
                  <div className="font-bold text-slate-950 text-sm">{student.fullName}</div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Student ID Number</div>
                  <div className="font-mono font-bold text-slate-950 text-sm">{student.studentId}</div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Sex / Gender</div>
                  <div className="font-semibold text-slate-900">{student.gender}</div>
                </div>
                <div className="col-span-2 sm:col-span-1">
                  <div className="text-slate-500 font-medium">College</div>
                  <div className="font-semibold text-slate-900">{student.college}</div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Department / Program</div>
                  <div className="font-semibold text-slate-900">{student.department} ({student.program})</div>
                </div>
                <div>
                  <div className="text-slate-500 font-medium">Cost Sharing Agreement</div>
                  <div className="font-mono font-semibold text-slate-900">{student.costSharingAgreementNo}</div>
                </div>
              </div>
            </div>

            {/* Verification Statement */}
            <div className="py-4 text-xs text-slate-700 leading-relaxed italic border-b border-slate-300">
              "This is to officially certify that the student named above has satisfactorily handed over all university
              properties, returned all library materials, resolved dormitory assignments, and fulfilled all financial,
              academic, and disciplinary obligations to Danbi Dollo University as recorded by the designated directors below."
            </div>

            {/* 9 Department Stamp & Signature Grid */}
            <div className="py-6">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-900 mb-4">
                Departmental Endorsements & Digital Stamps
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {(Object.keys(DEPARTMENTS_METADATA) as Array<keyof typeof DEPARTMENTS_METADATA>).map((key) => {
                  const meta = DEPARTMENTS_METADATA[key];
                  const approval = request.departments[key];
                  const isDeptCleared = approval?.status === 'CLEARED';

                  return (
                    <div
                      key={key}
                      className={`relative p-3 rounded border text-xs flex flex-col justify-between min-h-[110px] ${
                        isDeptCleared
                          ? 'border-slate-300 bg-slate-50/50'
                          : 'border-red-300 bg-red-50/30'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-slate-900 line-clamp-1">{meta.name}</div>
                        <div className="text-[10px] text-slate-500">{meta.subtitle}</div>
                      </div>

                      {isDeptCleared ? (
                        <div className="mt-2 pt-2 border-t border-slate-200">
                          {/* Simulated Official Rubber Stamp */}
                          <div className="border border-blue-800 text-blue-900 px-2 py-1 rounded text-center rotate-[-1deg] bg-blue-50/50">
                            <div className="text-[9px] font-mono uppercase font-bold tracking-tight">
                              DaDU APPROVED
                            </div>
                            <div className="text-[8px] font-mono text-blue-800">
                              {approval?.signatureCode || meta.stampCode}
                            </div>
                          </div>
                          <div className="flex justify-between items-center text-[10px] text-slate-600 mt-1.5 font-mono">
                            <span>{approval?.officerName?.split(' ')[0] || meta.leadOfficer.split(' ')[0]}</span>
                            <span>
                              {approval?.approvedAt
                                ? new Date(approval.approvedAt).toLocaleDateString('en-GB')
                                : 'CLEARED'}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-2 pt-2 border-t border-red-200 text-red-700 text-center">
                          <span className="text-[10px] font-semibold uppercase">Pending Verification</span>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Bottom Footer: Registrar Seal & QR Verification Code */}
            <div className="pt-6 border-t-2 border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-6">
              {/* QR Verification Block */}
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 p-1 bg-white border border-slate-900 rounded flex flex-col items-center justify-center">
                  {/* Procedural QR Code visualization */}
                  <div className="w-14 h-14 grid grid-cols-6 grid-rows-6 gap-0.5 bg-white">
                    <div className="bg-slate-900 col-span-2 row-span-2"></div>
                    <div className="bg-white col-span-1"></div>
                    <div className="bg-slate-900 col-span-3"></div>
                    <div className="bg-slate-900 col-span-1"></div>
                    <div className="bg-slate-900 col-span-2"></div>
                    <div className="bg-white col-span-2"></div>
                    <div className="bg-slate-900 col-span-2 row-span-2"></div>
                    <div className="bg-slate-900 col-span-2"></div>
                    <div className="bg-slate-900 col-span-1"></div>
                    <div className="bg-slate-900 col-span-3"></div>
                    <div className="bg-slate-900 col-span-1"></div>
                  </div>
                </div>
                <div className="text-[11px] text-slate-600">
                  <div className="font-bold text-slate-900">Security Verification Token</div>
                  <div className="font-mono text-[10px]">{request.qrValidationToken}</div>
                  <div className="text-[10px] text-slate-500">Scan to verify authenticity at dadu.edu.et/verify</div>
                </div>
              </div>

              {/* Registrar Seal and Signature */}
              <div className="text-center sm:text-right">
                <div className="inline-block text-center border-t border-slate-900 pt-1 min-w-[200px]">
                  <div className="font-serif italic font-bold text-slate-900 text-base tracking-wide">
                    Dr. Dereje Feyissa
                  </div>
                  <div className="text-xs font-semibold text-slate-900 uppercase">Director, University Registrar</div>
                  <div className="text-[10px] text-slate-600">Danbi Dollo University, Oromia, Ethiopia</div>
                </div>
              </div>
            </div>

            {/* Official Notice */}
            <div className="mt-4 pt-3 border-t border-slate-200 text-center text-[10px] text-slate-500 font-mono">
              Notice: Alteration or fraudulent duplication of this document constitutes a criminal offense under Ethiopian Federal Law.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
