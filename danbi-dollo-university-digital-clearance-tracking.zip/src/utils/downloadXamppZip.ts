import JSZip from 'jszip';

export async function downloadXamppPackage(onProgress?: (status: string) => void) {
  try {
    if (onProgress) onProgress('Preparing XAMPP package...');
    const zip = new JSZip();

    // 1. Fetch index.html
    if (onProgress) onProgress('Adding index.html...');
    try {
      const indexRes = await fetch('./index.html');
      if (indexRes.ok) {
        const indexHtml = await indexRes.text();
        zip.file('index.html', indexHtml);
      }
    } catch {
      // fallback to current document outerHTML
      zip.file('index.html', document.documentElement.outerHTML);
    }

    // 2. Add .htaccess
    const htaccessContent = `<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . index.html [L]
</IfModule>
`;
    zip.file('.htaccess', htaccessContent);

    // 3. Add README_XAMPP.txt in Afaan Oromoo and English
    const readmeContent = `========================================================================
DANBI DOLLO UNIVERSITY - DIGITAL CLEARANCE TRACKING SYSTEM
Qajeelfama XAMPP htdocs keessatti Hojjachiisuu (Localhost Guide)
========================================================================

Afaan Oromoo:
1. Zip kana baasi (Extract godhi).
2. Folder "dadu-clearance" jedhamu uumiitii faayiloota kana hunda:
   C:\\xampp\\htdocs\\dadu-clearance\\
   keessa paste godhi.
3. XAMPP Control Panel baniitii Apache "Start" godhi.
4. Browser kee irratti: http://localhost/dadu-clearance/ banee fayyadami!

English:
1. Extract all files from this zip.
2. Place them into: C:\\xampp\\htdocs\\dadu-clearance\\
3. Start Apache from the XAMPP Control Panel.
4. Open your browser and navigate to: http://localhost/dadu-clearance/
========================================================================
Danbi Dollo University - ICT Directorate
`;
    zip.file('README_XAMPP.txt', readmeContent);

    // 4. Fetch dadu_logo.jpg
    if (onProgress) onProgress('Adding DaDU University logo...');
    try {
      const logoRes = await fetch('./dadu_logo.jpg');
      if (logoRes.ok) {
        const blob = await logoRes.blob();
        zip.file('dadu_logo.jpg', blob);
      }
    } catch (e) {
      console.warn('Could not bundle logo:', e);
    }

    // 5. Look for linked CSS and JS in document head
    const assetsFolder = zip.folder('assets');
    const scripts = Array.from(document.querySelectorAll<HTMLScriptElement>('script[src]'));
    const styles = Array.from(document.querySelectorAll<HTMLLinkElement>('link[rel="stylesheet"][href]'));

    if (onProgress) onProgress('Packaging compiled JavaScript & CSS bundles...');
    
    for (const script of scripts) {
      const src = script.getAttribute('src');
      if (src && (src.includes('assets/') || src.endsWith('.js'))) {
        try {
          const res = await fetch(src);
          if (res.ok) {
            const content = await res.text();
            const filename = src.split('/').pop() || 'index.js';
            assetsFolder?.file(filename, content);
          }
        } catch (e) {
          console.warn('Error bundling script:', src, e);
        }
      }
    }

    for (const link of styles) {
      const href = link.getAttribute('href');
      if (href && (href.includes('assets/') || href.endsWith('.css'))) {
        try {
          const res = await fetch(href);
          if (res.ok) {
            const content = await res.text();
            const filename = href.split('/').pop() || 'index.css';
            assetsFolder?.file(filename, content);
          }
        } catch (e) {
          console.warn('Error bundling stylesheet:', href, e);
        }
      }
    }

    // Generate zip blob and trigger browser download
    if (onProgress) onProgress('Generating ZIP file...');
    const content = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(content);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dadu-clearance-xampp.zip';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    if (onProgress) onProgress('Completed! File downloaded.');
    return true;
  } catch (error) {
    console.error('Failed to create XAMPP package:', error);
    alert('Could not download package directly. Please use the AI Studio Export/Download option.');
    return false;
  }
}
