export type DepartmentKey =
  | 'academic_dept'
  | 'library'
  | 'dormitory'
  | 'cafeteria'
  | 'sports'
  | 'clinic'
  | 'cost_sharing'
  | 'campus_police'
  | 'registrar';

export type ClearanceType =
  | 'VACATION_EXIT'
  | 'LOST_ID_REPLACEMENT'
  | 'GRADUATION'
  | 'END_OF_YEAR'
  | 'WITHDRAWAL'
  | 'TRANSFER'
  | 'POSTGRADUATE';

export interface LostIdIncident {
  policeReportNo: string;
  incidentDate: string;
  incidentLocation: string;
  replacementFeeETB: number;
  replacementFeePaid: boolean;
  replacementReceiptNo?: string;
  replacementIdIssued: boolean;
  newStudentIdBarcode?: string;
}

export interface VacationExitPass {
  destinationTown: string;
  departureDate: string;
  expectedReturnDate: string;
  luggagePermitIssued: boolean;
  gateSecurityExitCleared: boolean;
}

export type ClearanceStatus =
  | 'INITIATED'
  | 'IN_PROGRESS'
  | 'ACTION_REQUIRED'
  | 'APPROVED'
  | 'REJECTED';

export type HoldCategory = 'PROPERTY' | 'FINANCIAL' | 'ACADEMIC' | 'DISCIPLINARY';

export interface ClearanceHold {
  id: string;
  item: string;
  category: HoldCategory;
  amountETB?: number;
  issuedDate: string;
  resolved: boolean;
  resolvedAt?: string;
  resolutionReceipt?: string;
  instructions: string;
}

export interface DepartmentApproval {
  departmentId: DepartmentKey;
  departmentName: string;
  officerName: string;
  officerTitle: string;
  buildingLocation: string;
  status: 'CLEARED' | 'PENDING' | 'HOLD';
  approvedAt?: string;
  signatureCode?: string;
  stampText?: string;
  notes?: string;
  holds: ClearanceHold[];
}

export interface Student {
  id: string;
  studentId: string;
  fullName: string;
  gender: 'Male' | 'Female';
  email: string;
  phone: string;
  college: string;
  department: string;
  yearOfStudy: string;
  password?: string;
  program: 'Regular' | 'Extension' | 'Weekend' | 'Postgraduate';
  admissionYear: string;
  completionYear: string;
  cgpa: number;
  avatarUrl: string;
  dormBlock?: string;
  dormRoom?: string;
  costSharingAgreementNo: string;
  nationalIdNo?: string;
}

export interface AuditEntry {
  id: string;
  timestamp: string;
  actor: string;
  action: string;
  note?: string;
}

export interface ClearanceRequest {
  id: string;
  student: Student;
  clearanceType: ClearanceType;
  reason: string;
  academicYear: string;
  semester: 'I' | 'II' | 'Summer';
  dateInitiated: string;
  overallStatus: ClearanceStatus;
  departments: Record<DepartmentKey, DepartmentApproval>;
  finalCertificateIssued: boolean;
  certificateIssueDate?: string;
  certificateSerial?: string;
  qrValidationToken: string;
  auditLog: AuditEntry[];
  lostIdIncident?: LostIdIncident;
  vacationExitPass?: VacationExitPass;
}

export type UserRole = 'STUDENT' | 'DEPARTMENT_OFFICER' | 'REGISTRAR' | 'SECURITY_VERIFIER';
