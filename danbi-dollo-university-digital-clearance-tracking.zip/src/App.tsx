import React, { useState } from 'react';
import { ClearanceProvider, useClearance } from './context/ClearanceContext';
import { Navbar } from './components/Navbar';
import { StudentPortal } from './components/StudentPortal';
import { DepartmentPortal } from './components/DepartmentPortal';
import { RegistrarHub } from './components/RegistrarHub';
import { VerifyCertificate } from './components/VerifyCertificate';
import { ClearanceGuide } from './components/ClearanceGuide';
import { StudentAuth } from './components/StudentAuth';
import { ClearanceCertificateModal } from './components/ClearanceCertificateModal';
import { VacationGatePassModal } from './components/VacationGatePassModal';
import { ReplacementIdCardModal } from './components/ReplacementIdCardModal';
import { ClearanceRequest } from './types/clearance';
import { DADU_EMBLEM_URL } from './data/mockData';

const AppContent: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'student' | 'department' | 'registrar' | 'verify' | 'guide'>('student');
  const [certificateModalRequest, setCertificateModalRequest] = useState<ClearanceRequest | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);

  const { currentRequest, requests, currentUser } = useClearance();

  const handleOpenCertificate = () => {
    // If current student has an approved certificate, open that, or find first approved
    if (currentRequest?.finalCertificateIssued) {
      setCertificateModalRequest(currentRequest);
    } else {
      const anyApproved = requests.find((r) => r.finalCertificateIssued);
      if (anyApproved) {
        setCertificateModalRequest(anyApproved);
      } else if (currentRequest) {
        setCertificateModalRequest(currentRequest);
      }
    }
  };

  const handleOpenCertificateFor = (req: ClearanceRequest) => {
    setCertificateModalRequest(req);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-900">
      {/* Top Bar Navigation */}
      <Navbar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenCertificate={handleOpenCertificate}
        onOpenAuthModal={() => setIsAuthModalOpen(true)}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {activeTab === 'student' && (
          currentUser ? (
            <StudentPortal
              onOpenCertificate={handleOpenCertificate}
              onOpenAuthModal={() => setIsAuthModalOpen(true)}
            />
          ) : (
            <div className="py-4">
              <StudentAuth onSuccess={() => {}} />
            </div>
          )
        )}

        {activeTab === 'department' && <DepartmentPortal />}

        {activeTab === 'registrar' && (
          <RegistrarHub onOpenCertificateFor={handleOpenCertificateFor} />
        )}

        {activeTab === 'verify' && <VerifyCertificate />}

        {activeTab === 'guide' && <ClearanceGuide />}
      </main>

      {/* Institutional Footer */}
      <footer className="no-print mt-auto border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <img
              src={DADU_EMBLEM_URL}
              alt="Dambi Dollo University Official Logo"
              className="w-6 h-6 object-contain"
              referrerPolicy="no-referrer"
            />
            <span>
              © 2026 Danbi Dollo University · Registrar & Information Systems Directorate
            </span>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() => setActiveTab('guide')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Clearance Regulations
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveTab('verify')}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Credential Verification
            </button>
            <span>·</span>
            <span>Dembi Dolo, Oromia, Ethiopia</span>
          </div>
        </div>
      </footer>

      {/* Printable Certificate / Document Modals according to clearance purpose */}
      {certificateModalRequest && (
        certificateModalRequest.clearanceType === 'VACATION_EXIT' ? (
          <VacationGatePassModal
            request={certificateModalRequest}
            onClose={() => setCertificateModalRequest(null)}
          />
        ) : certificateModalRequest.clearanceType === 'LOST_ID_REPLACEMENT' ? (
          <ReplacementIdCardModal
            request={certificateModalRequest}
            onClose={() => setCertificateModalRequest(null)}
          />
        ) : (
          <ClearanceCertificateModal
            request={certificateModalRequest}
            onClose={() => setCertificateModalRequest(null)}
          />
        )
      )}

      {/* Student Authentication & Registration Modal */}
      {isAuthModalOpen && (
        <StudentAuth
          isModal
          onClose={() => setIsAuthModalOpen(false)}
          onSuccess={() => setIsAuthModalOpen(false)}
        />
      )}
    </div>
  );
};

export default function App() {
  return (
    <ClearanceProvider>
      <AppContent />
    </ClearanceProvider>
  );
}
