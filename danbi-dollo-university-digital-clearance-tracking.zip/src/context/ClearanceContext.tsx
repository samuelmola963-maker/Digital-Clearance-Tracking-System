import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  ClearanceRequest,
  DepartmentKey,
  HoldCategory,
  Student,
  UserRole,
} from '../types/clearance';
import {
  DEPARTMENTS_METADATA,
  INITIAL_CLEARANCE_REQUESTS,
  INITIAL_STUDENTS,
  DADU_DEPARTMENTS_LIST,
  DADU_STUDENT_AVATAR,
} from '../data/mockData';

export interface PasswordValidationRules {
  hasMinLength: boolean; // >= 8 chars
  hasUpper: boolean; // At least one uppercase letter (A-Z)
  hasLower: boolean; // At least one lowercase letter (a-z)
  hasNumber: boolean; // At least one number (0-9)
  hasSpecial: boolean; // At least one special symbol (!@#$%^&*...)
  isValid: boolean;
}

export function validatePasswordRules(pwd: string): PasswordValidationRules {
  const hasMinLength = pwd.length >= 8;
  const hasUpper = /[A-Z]/.test(pwd);
  const hasLower = /[a-z]/.test(pwd);
  const hasNumber = /[0-9]/.test(pwd);
  const hasSpecial = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(pwd);
  return {
    hasMinLength,
    hasUpper,
    hasLower,
    hasNumber,
    hasSpecial,
    isValid: hasMinLength && hasUpper && hasLower && hasNumber && hasSpecial,
  };
}

export interface AuthUser {
  id: string;
  studentId: string;
  fullName: string;
  role: UserRole;
  department?: string;
  yearOfStudy?: string;
}

interface ClearanceContextType {
  requests: ClearanceRequest[];
  students: Student[];
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  activeStudentId: string;
  setActiveStudentId: (id: string) => void;
  activeDepartment: DepartmentKey;
  setActiveDepartment: (dept: DepartmentKey) => void;
  currentStudent: Student;
  currentRequest: ClearanceRequest | undefined;
  
  // Auth state & actions
  currentUser: AuthUser | null;
  registerStudent: (data: {
    fullName: string;
    studentId: string;
    department: string;
    yearOfStudy: string;
    password: string;
  }) => { success: boolean; message: string; student?: Student };
  loginStudent: (studentId: string, password: string) => { success: boolean; message: string; student?: Student };
  logout: () => void;

  // Actions
  initiateClearance: (data: {
    studentId: string;
    clearanceType: ClearanceRequest['clearanceType'];
    reason: string;
    academicYear: string;
    semester: 'I' | 'II' | 'Summer';
    vacationExitPass?: import('../types/clearance').VacationExitPass;
    lostIdIncident?: import('../types/clearance').LostIdIncident;
  }) => ClearanceRequest;
  approveDepartment: (requestId: string, deptKey: DepartmentKey, notes?: string) => void;
  placeHold: (
    requestId: string,
    deptKey: DepartmentKey,
    holdData: { item: string; category: HoldCategory; amountETB?: number; instructions: string }
  ) => void;
  resolveHold: (
    requestId: string,
    deptKey: DepartmentKey,
    holdId: string,
    paymentMethod?: string,
    receiptNumber?: string
  ) => void;
  registrarFinalApproval: (requestId: string) => void;
  batchApproveDepartment: (deptKey: DepartmentKey) => void;
  issueReplacementId: (requestId: string) => void;
  authorizeVacationGateExit: (requestId: string) => void;
  payLostIdReplacementFee: (requestId: string, method?: string) => void;
  resetToDemoData: () => void;
}

const STORAGE_REQUESTS_KEY = 'dadu_clearance_requests_v2';
const STORAGE_STUDENTS_KEY = 'dadu_students_v2';
const STORAGE_AUTH_USER_KEY = 'dadu_current_auth_user_v2';

const ClearanceContext = createContext<ClearanceContextType | undefined>(undefined);

export const ClearanceProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_STUDENTS_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return INITIAL_STUDENTS;
  });

  const [requests, setRequests] = useState<ClearanceRequest[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_REQUESTS_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return INITIAL_CLEARANCE_REQUESTS;
  });

  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_AUTH_USER_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return {
      id: INITIAL_STUDENTS[0].id,
      studentId: INITIAL_STUDENTS[0].studentId,
      fullName: INITIAL_STUDENTS[0].fullName,
      role: 'STUDENT',
      department: INITIAL_STUDENTS[0].department,
      yearOfStudy: INITIAL_STUDENTS[0].yearOfStudy,
    };
  });

  const [currentRole, setCurrentRole] = useState<UserRole>('STUDENT');
  const [activeStudentId, setActiveStudentId] = useState<string>(() => {
    return currentUser?.id || INITIAL_STUDENTS[0].id;
  });
  const [activeDepartment, setActiveDepartment] = useState<DepartmentKey>('library');

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_REQUESTS_KEY, JSON.stringify(requests));
    } catch (e) {
      console.error('Failed to sync requests to local storage', e);
    }
  }, [requests]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_STUDENTS_KEY, JSON.stringify(students));
    } catch (e) {
      console.error('Failed to sync students to local storage', e);
    }
  }, [students]);

  useEffect(() => {
    try {
      if (currentUser) {
        localStorage.setItem(STORAGE_AUTH_USER_KEY, JSON.stringify(currentUser));
      } else {
        localStorage.removeItem(STORAGE_AUTH_USER_KEY);
      }
    } catch (e) {
      console.error('Failed to sync auth user to local storage', e);
    }
  }, [currentUser]);

  const currentStudent = students.find((s) => s.id === activeStudentId) || students[0];
  const currentRequest = requests.find((r) => r.student.id === activeStudentId);

  // Helper to re-evaluate overallStatus of a request
  const calculateOverallStatus = (req: ClearanceRequest): ClearanceRequest['overallStatus'] => {
    if (req.finalCertificateIssued) return 'APPROVED';
    const deptList = Object.values(req.departments);
    const hasActiveHolds = deptList.some((d) => d.status === 'HOLD' || d.holds.some((h) => !h.resolved));
    if (hasActiveHolds) return 'ACTION_REQUIRED';
    
    // Check if non-registrar departments are all cleared
    const allPreRegistrarCleared = (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).filter(
      (k) => k !== 'registrar'
    ).every((k) => req.departments[k]?.status === 'CLEARED');
    
    if (allPreRegistrarCleared) {
      return req.departments.registrar?.status === 'CLEARED' ? 'APPROVED' : 'IN_PROGRESS';
    }
    return 'IN_PROGRESS';
  };

  const registerStudent = (data: {
    fullName: string;
    studentId: string;
    department: string;
    yearOfStudy: string;
    password: string;
  }): { success: boolean; message: string; student?: Student } => {
    const trimmedId = data.studentId.trim();
    const existing = students.find(
      (s) => s.studentId.toLowerCase() === trimmedId.toLowerCase()
    );

    if (existing) {
      return {
        success: false,
        message: `A student with ID "${trimmedId}" is already registered. Please log in instead.`,
      };
    }

    const rules = validatePasswordRules(data.password);
    if (!rules.isValid) {
      return {
        success: false,
        message: 'Password does not satisfy all required security rules.',
      };
    }

    // Determine college from department list
    const foundDept = DADU_DEPARTMENTS_LIST.find(
      (d) => d.name.toLowerCase() === data.department.toLowerCase()
    );
    const college = foundDept ? foundDept.college : 'College of Engineering and Technology';

    const newStudentId = `std_${Date.now()}`;
    const newStudent: Student = {
      id: newStudentId,
      studentId: trimmedId,
      fullName: data.fullName.trim(),
      gender: 'Male', // default
      email: `${trimmedId.replace(/[^a-zA-Z0-9]/g, '.').toLowerCase()}@student.dadu.edu.et`,
      phone: '+251 9' + Math.floor(10000000 + Math.random() * 90000000),
      college,
      department: data.department,
      yearOfStudy: data.yearOfStudy,
      password: data.password,
      program: 'Regular',
      admissionYear: '2022',
      completionYear: '2026',
      cgpa: 3.50,
      avatarUrl: DADU_STUDENT_AVATAR,
      dormBlock: 'Block ' + Math.floor(10 + Math.random() * 20),
      dormRoom: 'Room ' + Math.floor(100 + Math.random() * 350),
      costSharingAgreementNo: `CS-DaDU-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      nationalIdNo: `ETH-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    const updatedStudents = [newStudent, ...students];
    setStudents(updatedStudents);

    // Automatically initialize an active clearance tracker for the newly registered student
    const newDepartments: ClearanceRequest['departments'] = {} as any;
    (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).forEach((key) => {
      const meta = DEPARTMENTS_METADATA[key];
      newDepartments[key] = {
        departmentId: key,
        departmentName: meta.name,
        officerName: meta.leadOfficer,
        officerTitle: meta.title,
        buildingLocation: meta.building,
        status: 'PENDING',
        holds: [],
      };
    });

    const newReq: ClearanceRequest = {
      id: `clr_${Date.now()}`,
      student: newStudent,
      clearanceType: data.yearOfStudy.includes('Graduating') ? 'GRADUATION' : 'END_OF_YEAR',
      reason: `Clearance application for ${data.yearOfStudy} - ${data.fullName}`,
      academicYear: '2025/2026',
      semester: 'II',
      dateInitiated: new Date().toISOString(),
      overallStatus: 'IN_PROGRESS',
      departments: newDepartments,
      finalCertificateIssued: false,
      qrValidationToken: `dadu-v1-${newStudent.studentId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now().toString(36)}`,
      auditLog: [
        {
          id: `aud_${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: newStudent.fullName,
          action: 'Account Created & Clearance Initiated',
          note: `Student registered in ${newStudent.department} (${newStudent.yearOfStudy}). Clearance tracking opened.`,
        },
      ],
    };

    setRequests((prev) => [newReq, ...prev]);

    // Log the user in
    const authUser: AuthUser = {
      id: newStudent.id,
      studentId: newStudent.studentId,
      fullName: newStudent.fullName,
      role: 'STUDENT',
      department: newStudent.department,
      yearOfStudy: newStudent.yearOfStudy,
    };
    setCurrentUser(authUser);
    setActiveStudentId(newStudent.id);
    setCurrentRole('STUDENT');

    return {
      success: true,
      message: 'Accountiin barataa milkaa\'inaan uumamee jira! Baga nagaan dhuftan (Account created successfully!).',
      student: newStudent,
    };
  };

  const loginStudent = (
    studentId: string,
    password: string
  ): { success: boolean; message: string; student?: Student } => {
    const trimmedId = studentId.trim();
    const student = students.find(
      (s) => s.studentId.toLowerCase() === trimmedId.toLowerCase()
    );

    if (!student) {
      return {
        success: false,
        message: `Student ID "${trimmedId}" was not found. Please check your ID or create an account.`,
      };
    }

    if (student.password && student.password !== password) {
      return {
        success: false,
        message: 'Incorrect password. Please try again.',
      };
    }

    const authUser: AuthUser = {
      id: student.id,
      studentId: student.studentId,
      fullName: student.fullName,
      role: 'STUDENT',
      department: student.department,
      yearOfStudy: student.yearOfStudy,
    };
    setCurrentUser(authUser);
    setActiveStudentId(student.id);
    setCurrentRole('STUDENT');

    return {
      success: true,
      message: `Welcome back, ${student.fullName}!`,
      student,
    };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const initiateClearance = (data: {
    studentId: string;
    clearanceType: ClearanceRequest['clearanceType'];
    reason: string;
    academicYear: string;
    semester: 'I' | 'II' | 'Summer';
    vacationExitPass?: import('../types/clearance').VacationExitPass;
    lostIdIncident?: import('../types/clearance').LostIdIncident;
  }): ClearanceRequest => {
    const student = students.find((s) => s.id === data.studentId) || students[0];
    
    // Initialize department slots
    const newDepartments: ClearanceRequest['departments'] = {} as any;
    (Object.keys(DEPARTMENTS_METADATA) as DepartmentKey[]).forEach((key) => {
      const meta = DEPARTMENTS_METADATA[key];
      newDepartments[key] = {
        departmentId: key,
        departmentName: meta.name,
        officerName: meta.leadOfficer,
        officerTitle: meta.title,
        buildingLocation: meta.building,
        status: 'PENDING',
        holds: [],
      };
    });

    let vacationExitPass = data.vacationExitPass;
    let lostIdIncident = data.lostIdIncident;

    // Default configuration for Vacation Exit (Boqonnaaf Gibiidhaa Ba'uu)
    if (data.clearanceType === 'VACATION_EXIT') {
      if (!vacationExitPass) {
        const today = new Date().toISOString().split('T')[0];
        const nextMonth = new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
        vacationExitPass = {
          destinationTown: 'Nekemte',
          departureDate: today,
          expectedReturnDate: nextMonth,
          luggagePermitIssued: true,
          gateSecurityExitCleared: false,
        };
      }

      // Add dormitory key handover hold
      newDepartments.dormitory.status = 'HOLD';
      newDepartments.dormitory.holds = [
        {
          id: `hld_drm_${Date.now()}`,
          item: `Room Lock Key Return (${student.dormBlock || 'Dorm Block'}, ${student.dormRoom || 'Room'})`,
          category: 'PROPERTY',
          amountETB: 120,
          issuedDate: new Date().toISOString(),
          resolved: false,
          instructions: 'Surrender room key to Block Proctor and complete luggage inspection before exit.',
        },
      ];

      // Auto-clear academic dept for semester break
      newDepartments.academic_dept.status = 'CLEARED';
      newDepartments.academic_dept.approvedAt = new Date().toISOString();
      newDepartments.academic_dept.notes = 'Semester coursework completed. Eligible for vacation break.';
    }

    // Default configuration for Lost Student ID Replacement (Clearance Yeroo ID Card Gatan)
    if (data.clearanceType === 'LOST_ID_REPLACEMENT') {
      if (!lostIdIncident) {
        lostIdIncident = {
          policeReportNo: `DaDU-POL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
          incidentDate: new Date().toISOString().split('T')[0],
          incidentLocation: 'Main Campus',
          replacementFeeETB: 150,
          replacementFeePaid: false,
          replacementIdIssued: false,
        };
      }

      // Police cleared incident report
      newDepartments.campus_police.status = 'CLEARED';
      newDepartments.campus_police.approvedAt = new Date().toISOString();
      newDepartments.campus_police.notes = `Lost ID incident report filed under #${lostIdIncident.policeReportNo}. Identity verified.`;

      // Cafeteria blocks lost meal card barcode
      newDepartments.cafeteria.status = 'CLEARED';
      newDepartments.cafeteria.approvedAt = new Date().toISOString();
      newDepartments.cafeteria.notes = 'Lost card meal barcode blocked and blacklisted to prevent meal fraud.';

      // Finance hold for 150 ETB card replacement fee
      newDepartments.cost_sharing.status = 'HOLD';
      newDepartments.cost_sharing.holds = [
        {
          id: `hld_fin_lost_id_${Date.now()}`,
          item: 'Student ID Card Replacement Service Fee (150 ETB)',
          category: 'FINANCIAL',
          amountETB: 150,
          issuedDate: new Date().toISOString(),
          resolved: false,
          instructions: 'Pay 150 ETB via Telebirr or CBE Birr to Finance Directorate to authorize printing new ID.',
        },
      ];
    }

    const newRequest: ClearanceRequest = {
      id: `clr_${Date.now()}`,
      student,
      clearanceType: data.clearanceType,
      reason: data.reason,
      academicYear: data.academicYear,
      semester: data.semester,
      dateInitiated: new Date().toISOString(),
      overallStatus: 'IN_PROGRESS',
      departments: newDepartments,
      finalCertificateIssued: false,
      qrValidationToken: `dadu-v1-${student.studentId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now().toString(36)}`,
      vacationExitPass,
      lostIdIncident,
      auditLog: [
        {
          id: `aud_${Date.now()}`,
          timestamp: new Date().toISOString(),
          actor: student.fullName,
          action: 'Clearance Application Submitted',
          note: `Initiated ${data.clearanceType} clearance application.`,
        },
      ],
    };

    if (newDepartments.dormitory.status === 'HOLD' || newDepartments.cost_sharing.status === 'HOLD') {
      newRequest.overallStatus = 'ACTION_REQUIRED';
    }

    setRequests((prev) => [newRequest, ...prev.filter((r) => r.student.id !== student.id)]);
    setActiveStudentId(student.id);
    return newRequest;
  };

  const approveDepartment = (requestId: string, deptKey: DepartmentKey, notes?: string) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const meta = DEPARTMENTS_METADATA[deptKey];
        const updatedDept = {
          ...req.departments[deptKey],
          status: 'CLEARED' as const,
          approvedAt: new Date().toISOString(),
          signatureCode: `SIG-${deptKey.toUpperCase().slice(0, 4)}-${Math.floor(10000 + Math.random() * 90000)}`,
          stampText: `${meta.name.toUpperCase()} - OFFICIALLY CLEARED`,
          notes: notes || req.departments[deptKey].notes || 'Clearance conditions verified and passed.',
        };

        const updatedDepartments = {
          ...req.departments,
          [deptKey]: updatedDept,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: `${meta.leadOfficer} (${meta.name})`,
            action: 'Cleared & Digitally Signed',
            note: notes || 'Verified zero outstanding university liabilities.',
          },
        ];

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: updatedDepartments,
          auditLog: updatedAudit,
        };

        updatedReq.overallStatus = calculateOverallStatus(updatedReq);
        return updatedReq;
      })
    );
  };

  const placeHold = (
    requestId: string,
    deptKey: DepartmentKey,
    holdData: { item: string; category: HoldCategory; amountETB?: number; instructions: string }
  ) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const meta = DEPARTMENTS_METADATA[deptKey];
        const newHold = {
          id: `hld_${Date.now()}`,
          item: holdData.item,
          category: holdData.category,
          amountETB: holdData.amountETB,
          issuedDate: new Date().toISOString(),
          resolved: false,
          instructions: holdData.instructions,
        };

        const currentDept = req.departments[deptKey];
        const updatedDept = {
          ...currentDept,
          status: 'HOLD' as const,
          holds: [...currentDept.holds, newHold],
          notes: `Liability recorded: ${holdData.item}`,
        };

        const updatedDepartments = {
          ...req.departments,
          [deptKey]: updatedDept,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: `${meta.leadOfficer} (${meta.name})`,
            action: 'Hold Placed',
            note: `${holdData.item} (${holdData.amountETB ? holdData.amountETB + ' ETB' : 'Item return needed'})`,
          },
        ];

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: updatedDepartments,
          auditLog: updatedAudit,
          overallStatus: 'ACTION_REQUIRED',
        };

        return updatedReq;
      })
    );
  };

  const resolveHold = (
    requestId: string,
    deptKey: DepartmentKey,
    holdId: string,
    paymentMethod = 'Telebirr / CBE Birr',
    receiptNumber?: string
  ) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const currentDept = req.departments[deptKey];
        let resolvedItemName = '';
        
        const updatedHolds = currentDept.holds.map((h) => {
          if (h.id === holdId) {
            resolvedItemName = h.item;
            return {
              ...h,
              resolved: true,
              resolvedAt: new Date().toISOString(),
              resolutionReceipt: receiptNumber || `TXN-DADU-${Math.floor(100000 + Math.random() * 900000)}`,
            };
          }
          return h;
        });

        const stillHasUnresolvedHolds = updatedHolds.some((h) => !h.resolved);
        const updatedStatus = stillHasUnresolvedHolds ? 'HOLD' : 'CLEARED';

        const updatedDept = {
          ...currentDept,
          status: updatedStatus as 'CLEARED' | 'HOLD',
          holds: updatedHolds,
          approvedAt: !stillHasUnresolvedHolds ? new Date().toISOString() : currentDept.approvedAt,
          signatureCode: !stillHasUnresolvedHolds
            ? `SIG-${deptKey.toUpperCase().slice(0, 4)}-${Math.floor(10000 + Math.random() * 90000)}`
            : currentDept.signatureCode,
          notes: !stillHasUnresolvedHolds
            ? 'All liabilities cleared and validated.'
            : currentDept.notes,
        };

        const updatedDepartments = {
          ...req.departments,
          [deptKey]: updatedDept,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: 'System / Finance Settlement',
            action: 'Hold Resolved',
            note: `Resolved "${resolvedItemName}" via ${paymentMethod}.`,
          },
        ];

        let updatedLostIdIncident = req.lostIdIncident;
        if (req.clearanceType === 'LOST_ID_REPLACEMENT' && (deptKey === 'cost_sharing' || resolvedItemName.toLowerCase().includes('replacement') || resolvedItemName.toLowerCase().includes('150'))) {
          updatedLostIdIncident = req.lostIdIncident ? {
            ...req.lostIdIncident,
            replacementFeePaid: true,
            replacementReceiptNo: receiptNumber || `TXN-DADU-${Math.floor(100000 + Math.random() * 900000)}`,
          } : undefined;
        }

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: updatedDepartments,
          lostIdIncident: updatedLostIdIncident,
          auditLog: updatedAudit,
        };

        updatedReq.overallStatus = calculateOverallStatus(updatedReq);
        return updatedReq;
      })
    );
  };

  const registrarFinalApproval = (requestId: string) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const serial = `DaDU-CLR-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        const regMeta = DEPARTMENTS_METADATA.registrar;

        const updatedRegistrar = {
          ...req.departments.registrar,
          status: 'CLEARED' as const,
          approvedAt: new Date().toISOString(),
          signatureCode: 'SIG-REG-00001',
          stampText: 'OFFICE OF THE REGISTRAR - GRADUATION CLEARED',
          notes: 'Full institutional clearance completed. Degree diploma & transcript unlocked.',
        };

        const updatedDepartments = {
          ...req.departments,
          registrar: updatedRegistrar,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: `${regMeta.leadOfficer} (${regMeta.name})`,
            action: 'Final Registrar Clearance & Certificate Release',
            note: `Official Certificate generated with serial ${serial}.`,
          },
        ];

        return {
          ...req,
          departments: updatedDepartments,
          finalCertificateIssued: true,
          certificateIssueDate: new Date().toISOString(),
          certificateSerial: serial,
          overallStatus: 'APPROVED',
          auditLog: updatedAudit,
        };
      })
    );
  };

  const batchApproveDepartment = (deptKey: DepartmentKey) => {
    setRequests((prev) =>
      prev.map((req) => {
        const dept = req.departments[deptKey];
        if (dept.holds.some((h) => !h.resolved)) return req;
        if (dept.status === 'CLEARED') return req;

        const meta = DEPARTMENTS_METADATA[deptKey];
        const updatedDept = {
          ...dept,
          status: 'CLEARED' as const,
          approvedAt: new Date().toISOString(),
          signatureCode: `SIG-${deptKey.toUpperCase().slice(0, 4)}-${Math.floor(10000 + Math.random() * 90000)}`,
          stampText: `${meta.name.toUpperCase()} - BATCH CLEARED`,
          notes: 'Batch verification passed.',
        };

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: {
            ...req.departments,
            [deptKey]: updatedDept,
          },
          auditLog: [
            ...req.auditLog,
            {
              id: `aud_${Date.now()}`,
              timestamp: new Date().toISOString(),
              actor: `${meta.leadOfficer} (${meta.name})`,
              action: 'Batch Approved',
              note: 'Standard batch clearance approval without holds.',
            },
          ],
        };

        updatedReq.overallStatus = calculateOverallStatus(updatedReq);
        return updatedReq;
      })
    );
  };

  const issueReplacementId = (requestId: string) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const newBarcode = `DADU-ID-2026-${Math.floor(100000 + Math.random() * 900000)}`;
        const regMeta = DEPARTMENTS_METADATA.registrar;

        const updatedLostIdIncident = req.lostIdIncident
          ? {
              ...req.lostIdIncident,
              replacementIdIssued: true,
              newStudentIdBarcode: newBarcode,
            }
          : {
              policeReportNo: `DaDU-POL-2026-${Math.floor(1000 + Math.random() * 9000)}`,
              incidentDate: new Date().toISOString().split('T')[0],
              incidentLocation: 'Main Campus',
              replacementFeeETB: 150,
              replacementFeePaid: true,
              replacementIdIssued: true,
              newStudentIdBarcode: newBarcode,
            };

        const updatedRegistrar = {
          ...req.departments.registrar,
          status: 'CLEARED' as const,
          approvedAt: new Date().toISOString(),
          signatureCode: 'SIG-REG-ID-REPLACE',
          stampText: 'OFFICE OF THE REGISTRAR - REPLACEMENT ID AUTHORIZED & PRINTED',
          notes: `Replacement Student ID successfully issued. New Card Barcode: ${newBarcode}. Previous card deactivated across all systems.`,
        };

        const updatedDepartments = {
          ...req.departments,
          registrar: updatedRegistrar,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: `${regMeta.leadOfficer} (${regMeta.name})`,
            action: 'Replacement Student ID Issued & Printed',
            note: `Multi-sector clearance completed. New ID Card Barcode #${newBarcode} generated.`,
          },
        ];

        return {
          ...req,
          departments: updatedDepartments,
          lostIdIncident: updatedLostIdIncident,
          finalCertificateIssued: true,
          certificateIssueDate: new Date().toISOString(),
          certificateSerial: `DaDU-REPL-ID-${Math.floor(1000 + Math.random() * 9000)}`,
          overallStatus: 'APPROVED',
          auditLog: updatedAudit,
        };
      })
    );
  };

  const authorizeVacationGateExit = (requestId: string) => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const policeMeta = DEPARTMENTS_METADATA.campus_police;
        const passSerial = `DaDU-GATE-PASS-${Math.floor(1000 + Math.random() * 9000)}`;

        const updatedVacationPass = req.vacationExitPass
          ? {
              ...req.vacationExitPass,
              gateSecurityExitCleared: true,
              luggagePermitIssued: true,
            }
          : {
              destinationTown: 'Nekemte',
              departureDate: new Date().toISOString().split('T')[0],
              expectedReturnDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              luggagePermitIssued: true,
              gateSecurityExitCleared: true,
            };

        const updatedPolice = {
          ...req.departments.campus_police,
          status: 'CLEARED' as const,
          approvedAt: new Date().toISOString(),
          signatureCode: 'SIG-GATE-EXIT-PERMIT',
          stampText: 'CAMPUS POLICE MAIN GATE - VACATION EXIT CLEARED',
          notes: `Luggage inspection completed at Main Gate. Student authorized for vacation departure to ${updatedVacationPass.destinationTown}. Pass Serial: ${passSerial}`,
        };

        const updatedDepartments = {
          ...req.departments,
          campus_police: updatedPolice,
        };

        const updatedAudit = [
          ...req.auditLog,
          {
            id: `aud_${Date.now()}`,
            timestamp: new Date().toISOString(),
            actor: `${policeMeta.leadOfficer} (${policeMeta.name})`,
            action: 'Vacation Campus Exit & Luggage Pass Authorized',
            note: `Main Gate security clearance authorized. Exit pass #${passSerial} generated for travel to ${updatedVacationPass.destinationTown}.`,
          },
        ];

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: updatedDepartments,
          vacationExitPass: updatedVacationPass,
          finalCertificateIssued: true,
          certificateIssueDate: new Date().toISOString(),
          certificateSerial: passSerial,
          auditLog: updatedAudit,
        };

        updatedReq.overallStatus = calculateOverallStatus(updatedReq);
        return updatedReq;
      })
    );
  };

  const payLostIdReplacementFee = (requestId: string, method = 'Telebirr') => {
    setRequests((prev) =>
      prev.map((req) => {
        if (req.id !== requestId) return req;
        const receiptNo = `TXN-DADU-ID-${Math.floor(100000 + Math.random() * 900000)}`;

        // Resolve cost_sharing hold if any
        const currentCostDept = req.departments.cost_sharing;
        const updatedHolds = currentCostDept.holds.map((h) => ({
          ...h,
          resolved: true,
          resolvedAt: new Date().toISOString(),
          resolutionReceipt: receiptNo,
        }));

        const updatedCostDept = {
          ...currentCostDept,
          status: 'CLEARED' as const,
          holds: updatedHolds,
          approvedAt: new Date().toISOString(),
          signatureCode: 'SIG-FIN-ID-FEE-PAID',
          notes: `150 ETB ID replacement fee paid via ${method}. Receipt: ${receiptNo}`,
        };

        const updatedLostIdIncident = req.lostIdIncident
          ? {
              ...req.lostIdIncident,
              replacementFeePaid: true,
              replacementReceiptNo: receiptNo,
            }
          : undefined;

        const updatedReq: ClearanceRequest = {
          ...req,
          departments: {
            ...req.departments,
            cost_sharing: updatedCostDept,
          },
          lostIdIncident: updatedLostIdIncident,
          auditLog: [
            ...req.auditLog,
            {
              id: `aud_${Date.now()}`,
              timestamp: new Date().toISOString(),
              actor: `${req.student.fullName} (Finance Office)`,
              action: 'Replacement Fee Paid',
              note: `150 ETB paid via ${method}. Receipt #${receiptNo}. Finance hold resolved.`,
            },
          ],
        };

        updatedReq.overallStatus = calculateOverallStatus(updatedReq);
        return updatedReq;
      })
    );
  };

  const resetToDemoData = () => {
    localStorage.removeItem(STORAGE_REQUESTS_KEY);
    localStorage.removeItem(STORAGE_STUDENTS_KEY);
    localStorage.removeItem(STORAGE_AUTH_USER_KEY);
    setRequests(INITIAL_CLEARANCE_REQUESTS);
    setStudents(INITIAL_STUDENTS);
    setActiveStudentId(INITIAL_STUDENTS[0].id);
    setCurrentUser({
      id: INITIAL_STUDENTS[0].id,
      studentId: INITIAL_STUDENTS[0].studentId,
      fullName: INITIAL_STUDENTS[0].fullName,
      role: 'STUDENT',
      department: INITIAL_STUDENTS[0].department,
      yearOfStudy: INITIAL_STUDENTS[0].yearOfStudy,
    });
  };

  return (
    <ClearanceContext.Provider
      value={{
        requests,
        students,
        currentRole,
        setCurrentRole,
        activeStudentId,
        setActiveStudentId,
        activeDepartment,
        setActiveDepartment,
        currentStudent,
        currentRequest,
        currentUser,
        registerStudent,
        loginStudent,
        logout,
        initiateClearance,
        approveDepartment,
        placeHold,
        resolveHold,
        registrarFinalApproval,
        batchApproveDepartment,
        issueReplacementId,
        authorizeVacationGateExit,
        payLostIdReplacementFee,
        resetToDemoData,
      }}
    >
      {children}
    </ClearanceContext.Provider>
  );
};

export const useClearance = () => {
  const context = useContext(ClearanceContext);
  if (!context) {
    throw new Error('useClearance must be used within a ClearanceProvider');
  }
  return context;
};
